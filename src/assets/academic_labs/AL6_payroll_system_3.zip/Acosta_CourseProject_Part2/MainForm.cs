﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;
using static Acosta_CourseProject_Part2.MainForm;

namespace Acosta_CourseProject_Part2
{
    public partial class MainForm : Form
    {
        //class level references
        private const string FILENAME = "Employee.dat";
        public MainForm()
        {
            InitializeComponent();
        }

        private void AddButton_Click(object sender, EventArgs e)
        {
            // add item to the employee listbox
            InputForm frmInput = new InputForm();

            using (frmInput)
            {
                DialogResult result = frmInput.ShowDialog();

                // see if input form was cancelled
                if (result == DialogResult.Cancel)
                    return;    //  end the method since the user cancelled the input

                // get user's input and create an Employee object
                string fName = frmInput.FirstNameTextBox.Text;
                string lName = frmInput.LastNameTextBox.Text;
                string ssn = frmInput.SSNTextBox.Text;
                string date = frmInput.HireDateTextBox.Text;
                DateTime hireDate = DateTime.Parse(date);
                string healthIns = frmInput.HealthInsuranceTextBox.Text;
                int lifeIns = int.Parse(frmInput.LifeInsuranceTextBox.Text);
                int vacation = int.Parse(frmInput.VacationDaysTextBox.Text);

                Benefits ben = new Benefits(healthIns, lifeIns, vacation);
                Employee emp = null; //empty reference

                if (frmInput.SalaryRadioButton.Checked)
                {
                    double salary = double.Parse(frmInput.SalaryTextBox.Text);
                    emp = new Salary(fName, lName, ssn, hireDate, ben, salary);
                }
                else if (frmInput.HourlyRadioButton.Checked)
                {
                    double hourlyRate = double.Parse(frmInput.HourlyRateTextBox.Text);
                    double hoursWorked = double.Parse(frmInput.HoursWorkedTextBox.Text);
                    emp = new Hourly(fName, lName, ssn, hireDate, ben, hourlyRate, hoursWorked);
                }
                else
                {
                    MessageBox.Show("Error, Please select an employee type.");
                        return; //end the method
                }
                // add the Employee object to the employees listbox
                EmployeesListBox.Items.Add(emp);

                //Write all data to the file
                WriteEmpsToFile();

                }
            }
        private void WriteEmpsToFile()
        {
            //convert the ListBox Items to a generic list
            List<Employee> empList = new List<Employee>();

            foreach (Employee emp in EmployeesListBox.Items)
            {
                empList.Add(emp);
            }

            //open a pipe to the file and create a translator
            FileStream fs = new FileStream(FILENAME, FileMode.Create);
            BinaryFormatter formatter = new BinaryFormatter();

            //Write the generic list to the file
            formatter.Serialize(fs, empList);

            //close the pipe
            fs.Close();
        }

        private void RemoveButton_Click(object sender, EventArgs e)
        {
            // remove the selected employee from the listbox
            int itemNumber = EmployeesListBox.SelectedIndex;

            if (itemNumber > -1)
            {
                EmployeesListBox.Items.RemoveAt(itemNumber);
                WriteEmpsToFile();
            }
            else
            {
                MessageBox.Show("Please select an employee to remove.");
            }

        }

        private void DisplayButton_Click(object sender, EventArgs e)
        {
            //check to see if the file exists
            if(File.Exists(FILENAME) && new FileInfo(FILENAME).Length > 0)
            {
                //create a pipe from the file and create a translator
                FileStream fs = new FileStream(FILENAME, FileMode.Open);
                BinaryFormatter formatter = new BinaryFormatter();

                //read the generic list form the file
                List<Employee> list = (List<Employee>)formatter.Deserialize(fs);

                //close the pipe
                fs.Close();

                //Clear employee list box
                EmployeesListBox.Items.Clear();

                foreach (Employee emp in list)
                {
                    EmployeesListBox.Items.Add(emp);
                }
            }
        }

        private void PrintPaychecksButton_Click(object sender, EventArgs e)
        {
            foreach(Employee emp in EmployeesListBox.Items)
            {
                string line1 = "Pay To: " + emp.FirstName + " " + emp.LastName;
                string line2 = "Amount Of: " + emp.CalculatePay().ToString("C2");

                string output = "Paycheck: \n\n" + line1 + "\n" + line2;

                MessageBox.Show(output);
            }
        }

        private void EmployeesListBox_DoubleClick(object sender, EventArgs e)
        {
            //get the selected Employee object
            Employee emp = EmployeesListBox.SelectedItem as Employee;

            //show the Input/updat form with the employee information
            InputForm formUpdate = new InputForm();
            formUpdate.FirstNameTextBox.Text = emp.FirstName;
            formUpdate.LastNameTextBox.Text = emp.LastName;
            formUpdate.SSNTextBox.Text = emp.SSN;
            formUpdate.HireDateTextBox.Text = emp.HireDate.ToShortDateString();
            formUpdate.HealthInsuranceTextBox.Text = emp.BenefitsEmp.HealthInsurance;
            formUpdate.LifeInsuranceTextBox.Text = emp.BenefitsEmp.LifeInsurance.ToString();
            formUpdate.VacationDaysTextBox.Text= emp.BenefitsEmp.Vacation.ToString();
            
            //check to see if emp is a Salary or Hourly object

            if (emp is Salary)
            {
                formUpdate.HourlyRateLabel.Visible = false;
                formUpdate.HourlyRateTextBox.Visible = false;
                formUpdate.HoursWorkedLabel.Visible = false;
                formUpdate.HoursWorkedTextBox.Visible = false;
                formUpdate.SalaryLabel.Visible = true;
                formUpdate.SalaryTextBox.Visible = true;

                //mark the Salary radiobutton as checked
                formUpdate.SalaryRadioButton.Checked = true;

                //convert the Employee reference to a Salary object
                Salary sal = (Salary)emp;

                //show the Salary Information
                formUpdate.SalaryTextBox.Text = sal.AnnualSalary.ToString("F2");
            }
            else if (emp is Hourly)
            {
                formUpdate.HourlyRateLabel.Visible = true;
                formUpdate.HourlyRateTextBox.Visible = true;
                formUpdate.HoursWorkedLabel.Visible = true;
                formUpdate.HoursWorkedTextBox.Visible = true;
                formUpdate.SalaryLabel.Visible = false;
                formUpdate.SalaryTextBox.Visible = false;

                //mark the Hourly radiobutton as checked
                formUpdate.HourlyRadioButton.Checked = true;

                //convert the Employee reference to a Hourly object
                Hourly hrly = (Hourly)emp;

                //show the Hourly Information
                formUpdate.HourlyRateTextBox.Text = hrly.HourlyRate.ToString("F2");
                formUpdate.HoursWorkedTextBox.Text = hrly.HoursWorked.ToString("F2");
            }
            else
            {
                MessageBox.Show("Error. Invalid employee type founrd.");
                return; //end the method
            }
            
            DialogResult result = formUpdate.ShowDialog();

            //if canclled, stop the method
            if (result == DialogResult.Cancel)
                return; //end the method

            //delete the selected object
            int position = EmployeesListBox.SelectedIndex;
            EmployeesListBox.Items.RemoveAt(position);

            //create new employee using the updated information
            Employee newEmp = null;

            string fName= formUpdate.FirstNameTextBox.Text;
            string lName = formUpdate.LastNameTextBox.Text;
            string ssn = formUpdate.SSNTextBox.Text;
            DateTime hireDate = DateTime.Parse(formUpdate.HireDateTextBox.Text);
            string healthInsurance = formUpdate.HealthInsuranceTextBox.Text;
            int lifeInsurance = int.Parse(formUpdate.LifeInsuranceTextBox.Text);
            int vacation = int.Parse(formUpdate.VacationDaysTextBox.Text);

            Benefits ben = new Benefits(healthInsurance, lifeInsurance,vacation);

            if (formUpdate.SalaryRadioButton.Checked)
            {
                double salary = double.Parse(formUpdate.SalaryTextBox.Text);
                newEmp = new Salary(fName, lName, ssn, hireDate, ben, salary);
            }
            else if(formUpdate.HourlyRadioButton.Checked)
            {
                double hourlyRate = double.Parse(formUpdate.HourlyRateTextBox.Text);
                double hoursWorked = double.Parse(formUpdate.HoursWorkedTextBox.Text);
                newEmp = new Hourly(fName, lName, ssn, hireDate, ben, hourlyRate, hoursWorked);
            }
            else
            {
                MessageBox.Show("Error. Invalid Employee Type.");
                return; //end the method
            }

            //add the new employee to the listbox
            EmployeesListBox.Items.Add(newEmp);
        }
    }
}
