Add-Type -AssemblyName System.Drawing
$img = [System.Drawing.Image]::FromFile("D:\ADMIcon256x256.png")
$icon = [System.Drawing.Icon]::FromHandle($img.GetHicon())
$fs = New-Object System.IO.FileStream("D:\ADMIcon256x256.ico", 'Create')
$icon.Save($fs)
$fs.Close()
