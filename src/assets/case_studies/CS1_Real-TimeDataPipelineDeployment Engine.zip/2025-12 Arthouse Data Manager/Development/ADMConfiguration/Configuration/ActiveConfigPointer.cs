﻿/* 
    Developer: Francisco Acosta
    Company: NBC Universal - The Arthouse
    File Purpose: Pointer to tell the windows service which configuration file to use and establish default for fallback
*/

using System.IO;
using System.Text.Json;

namespace ADMConfiguration.Configuration
{
    public sealed class ActiveConfigPointer
    {
        public string? ConfigPath { get; set; }

        public static string DefaultPointerPath =>
            @"C:\ArthouseDataManager\Config\active.json";

        public static string ReadTargetPath(string pointerPath)
        {
            try
            {
                if (!File.Exists(pointerPath))
                    return @"C:\ArthouseDataManager\Config\config.json";

                var text = File.ReadAllText(pointerPath);
                var obj = JsonSerializer.Deserialize<ActiveConfigPointer>(text);
                var target = obj?.ConfigPath;
                return string.IsNullOrWhiteSpace(target)
                    ? @"C:\ArthouseDataManager\Config\config.json"
                    : target!;
            }
            catch
            {
                return @"C:\ArthouseDataManager\Config\config.json";
            }
        }
    }
}
