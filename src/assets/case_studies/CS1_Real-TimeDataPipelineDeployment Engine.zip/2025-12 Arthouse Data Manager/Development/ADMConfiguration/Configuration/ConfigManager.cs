﻿/* 
    Developer: Francisco Acosta
    Company: NBC Universal - The Arthouse
    File Purpose: Load and save configuration file
*/

using System.Text.Json;

namespace ADMConfiguration.Configuration
{
    public static class ConfigManager
    {
        public static async Task SaveConfigAsync(StreamManager config, string filePath)
        {
            var options = new JsonSerializerOptions { WriteIndented = true };
            string json = JsonSerializer.Serialize(config, options);
            await File.WriteAllTextAsync(filePath, json);
        }

        public static async Task<StreamManager> LoadConfigAsync(string filePath)
        {
            if (!File.Exists(filePath))
                return new StreamManager();

            string json = await File.ReadAllTextAsync(filePath);
            return JsonSerializer.Deserialize<StreamManager>(json)!;
        }
    }
}
