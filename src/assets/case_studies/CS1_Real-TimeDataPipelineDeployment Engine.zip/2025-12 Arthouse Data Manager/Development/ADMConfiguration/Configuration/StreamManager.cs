﻿/* 
    Developer: Francisco Acosta
    Company: NBC Universal - The Arthouse
    File Purpose: Create, remove and edit streams
*/

using ADMConfiguration.Data;

namespace ADMConfiguration.Configuration
{
    public class StreamManager
    {
        public List<DataStream> Streams { get; set; } = new List<DataStream>();

        public void AddStream(DataStream stream)
        {
            Streams.Add(stream);
        }

        public void RemoveStream(string name)
        {
            Streams.RemoveAll(s => s.Name.Equals(name, StringComparison.OrdinalIgnoreCase));
        }
    }
}
