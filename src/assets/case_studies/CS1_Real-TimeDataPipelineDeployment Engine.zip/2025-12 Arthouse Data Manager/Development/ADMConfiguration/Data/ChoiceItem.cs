﻿/* 
    Developer: Francisco Acosta
    Company: NBC Universal - The Arthouse
    File Purpose: Defines a data model for representing and labeling selectable JSON paths
*/

namespace ADMConfiguration.Data
{
    public enum ChoiceKind
    {
        Object,
        ArrayObject,
        ArrayPrimitive,
        Value
    }

    public sealed class ChoiceItem
    {
        /// JSON path
        public string Path { get; init; } = string.Empty;

        /// Label with type (for debugging/tooltip), e.g., "ElectionPlaylist.contest[].event.name (string)"
        public string Display { get; init; } = string.Empty;

        /// Compact friendly label, e.g., "event: name" or "id".
        public string DisplayShort { get; init; } = string.Empty;

        /// Kind of the item (container, array, leaf)
        public ChoiceKind Kind { get; init; } = ChoiceKind.Value;

        /// Type string ("string", "number", "boolean", "object", "array&lt;object&gt;", ...)
        public string Type { get; init; } = string.Empty;

        // Dependency metadata
        public string? ParentPath { get; init; }
        public IReadOnlyList<string> Ancestors { get; init; } = new List<string>();
        public int Depth { get; init; }

        /// Printable ancestor chain for tooltips
        public string AncestorsText =>
            Ancestors is null || Ancestors.Count == 0 ? "(none)" : string.Join(" → ", Ancestors);
    }
}
