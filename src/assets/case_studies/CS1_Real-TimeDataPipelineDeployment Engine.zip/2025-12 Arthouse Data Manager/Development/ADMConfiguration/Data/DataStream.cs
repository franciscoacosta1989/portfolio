﻿/* 
    Developer: Francisco Acosta
    Company: NBC Universal - The Arthouse
    File Purpose: Defines stream settings with validation and UI/JSON serialization.
*/

using System.Collections;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Text.Json.Serialization;

namespace ADMConfiguration.Data
{
    public class DataStream : INotifyPropertyChanged, INotifyDataErrorInfo
    {
        private string _name = string.Empty;
        private string _format = string.Empty;
        private string _delimiter = "|";

        // Nullable to allow "blank" (null) → "Time is required."
        private int? _intervalSeconds = null;

        // Leave blank initially so UI can show “required” error
        private string _fileLocation = string.Empty;

        private string _jsonUrl = string.Empty;

        private string _selectedObject = string.Empty;
        private string? _secondarySelectedObject = null;

        // --- UI-bound collections ---
        [JsonIgnore]
        public ObservableCollection<ChoiceItem> AvailableChoices { get; } = new();

        [JsonIgnore]
        public ObservableCollection<string> AvailableObjects { get; } = new();

        [JsonIgnore]
        public ObservableCollection<string> SelectedObjects { get; } = new();

        [JsonIgnore]
        public ObservableCollection<string> SelectedHeaders { get; } = new();

        // Per-column delimiter strings (UI)
        [JsonIgnore]
        public ObservableCollection<string> SelectedDelimiters { get; } = new();

        // ---- Surrogates for JSON ----
        [JsonPropertyName("SelectedObjects")]
        public List<string> SelectedObjectsForSerialization
        {
            get => SelectedObjects.ToList();
            set
            {
                SelectedObjects.Clear();
                if (value != null)
                {
                    foreach (var v in value) SelectedObjects.Add(v ?? string.Empty);
                }
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(SelectedObjects)));
            }
        }

        [JsonPropertyName("SelectedHeaders")]
        public List<string> SelectedHeadersForSerialization
        {
            get => SelectedHeaders.ToList();
            set
            {
                SelectedHeaders.Clear();
                if (value != null)
                {
                    foreach (var v in value) SelectedHeaders.Add(v ?? string.Empty);
                }
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(SelectedHeaders)));
            }
        }

        [JsonPropertyName("SelectedDelimiters")]
        public List<string> SelectedDelimitersForSerialization
        {
            get => SelectedDelimiters.ToList();
            set
            {
                SelectedDelimiters.Clear();
                if (value != null)
                {
                    foreach (var v in value)
                        SelectedDelimiters.Add(string.IsNullOrWhiteSpace(v) ? _delimiter : v);
                }
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(SelectedDelimiters)));
            }
        }

        public string Name
        {
            get => _name;
            set => SetField(ref _name, value ?? string.Empty);
        }

        public string Format
        {
            get => _format;
            set => SetField(ref _format, value ?? string.Empty);
        }

        /// Global delimiter used between columns.
        public string Delimiter
        {
            get => _delimiter;
            set => SetField(ref _delimiter, string.IsNullOrWhiteSpace(value) ? "|" : value);
        }

        /// Time interval in seconds. Nullable so a blank TextBox maps to null → "Time is required."
        public int? IntervalSeconds
        {
            get => _intervalSeconds;
            set => SetField(ref _intervalSeconds, value);
        }

        /// Final output directory (File 3). Can be blank
        public string FileLocation
        {
            get => _fileLocation;
            set => SetField(ref _fileLocation, value ?? string.Empty);
        }

        public string JsonUrl
        {
            get => _jsonUrl;
            set => SetField(ref _jsonUrl, value ?? string.Empty);
        }


        public string SelectedObject
        {
            get => _selectedObject;
            set => SetField(ref _selectedObject, value ?? string.Empty);
        }

        public string? SecondarySelectedObject
        {
            get => _secondarySelectedObject;
            set => SetField(ref _secondarySelectedObject, value);
        }

        /// If true, preserve last non-empty values when new values are null/empty.
        public bool PreserveLastNonEmptyValues { get; set; } = true;


        /// Directory for File 1 (current) – constantly overwritten from JSON.
        public string TemporaryDirectory { get; set; } = @"C:\ArthouseDataManager\Temp";


        /// Directory for File 2 (state)

        public string StateDirectory { get; set; } = @"C:\ArthouseDataManager\State";

        public override string ToString() => $"{Name} | {JsonUrl} | Every {(IntervalSeconds.HasValue ? IntervalSeconds.Value.ToString() : "(unset)")}s";


        public event PropertyChangedEventHandler? PropertyChanged;
        protected bool SetField<T>(ref T field, T value, [CallerMemberName] string? prop = null)
        {
            if (Equals(field, value)) return false;
            field = value;
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(prop));
            ValidateProperty(prop!);
            return true;
        }

        private readonly Dictionary<string, List<string>> _errors = new();

        public bool HasErrors => _errors.Count > 0;

        public event EventHandler<DataErrorsChangedEventArgs>? ErrorsChanged;

        public IEnumerable GetErrors(string? propertyName)
        {
            if (string.IsNullOrEmpty(propertyName)) return Enumerable.Empty<string>();
            return _errors.TryGetValue(propertyName, out var list) ? list : Enumerable.Empty<string>();
        }

        private void SetErrors(string propertyName, IEnumerable<string>? errors)
        {
            if (errors == null || !errors.Any())
            {
                if (_errors.Remove(propertyName))
                    ErrorsChanged?.Invoke(this, new DataErrorsChangedEventArgs(propertyName));
                return;
            }

            _errors[propertyName] = errors.ToList();
            ErrorsChanged?.Invoke(this, new DataErrorsChangedEventArgs(propertyName));
        }

        private void ValidateProperty(string propertyName)
        {
            switch (propertyName)
            {
                case nameof(Name):
                    SetErrors(nameof(Name),
                        string.IsNullOrWhiteSpace(Name)
                            ? new[] { "Stream Name is required." }
                            : null);
                    break;

                case nameof(JsonUrl):
                    SetErrors(nameof(JsonUrl),
                        string.IsNullOrWhiteSpace(JsonUrl)
                            ? new[] { "JSON URL is required." }
                            : null);
                    break;

                case nameof(FileLocation):
                    {
                        var errs = new List<string>();
                        if (string.IsNullOrWhiteSpace(FileLocation))
                        {
                            errs.Add("File Location is required.");
                        }
                        else
                        {
                            try
                            {
                                Directory.CreateDirectory(FileLocation);
                                var testFile = Path.Combine(FileLocation, ".adm_write_test.tmp");
                                using (File.Create(testFile)) { }
                                File.Delete(testFile);
                            }
                            catch (UnauthorizedAccessException)
                            {
                                errs.Add($"Cannot write to folder '{FileLocation}'. Choose a folder with write permissions.");
                            }
                            catch (Exception ex)
                            {
                                errs.Add($"File Location '{FileLocation}' is invalid or inaccessible. Details: {ex.Message}");
                            }
                        }
                        SetErrors(nameof(FileLocation), errs.Any() ? errs : null);
                    }
                    break;

                case nameof(IntervalSeconds):
                    {
                        var errs = new List<string>();

                        if (!IntervalSeconds.HasValue)
                        {
                            errs.Add("Time is required.");
                        }
                        else if (IntervalSeconds.Value <= 0)
                        {
                            errs.Add("Time (IntervalSeconds) must be greater than 0.");
                        }
                        else if (IntervalSeconds.Value > 86400)
                        {
                            errs.Add("Time (IntervalSeconds) must be ≤ 86400.");
                        }

                        SetErrors(nameof(IntervalSeconds), errs.Any() ? errs : null);
                    }
                    break;

                case nameof(Delimiter):
                    break;

                case nameof(Format):
                    break;
            }
        }

        public DataStream()
        {
            ValidateProperty(nameof(Name));
            ValidateProperty(nameof(JsonUrl));
            ValidateProperty(nameof(FileLocation));
            ValidateProperty(nameof(IntervalSeconds));
        }
    }
}
