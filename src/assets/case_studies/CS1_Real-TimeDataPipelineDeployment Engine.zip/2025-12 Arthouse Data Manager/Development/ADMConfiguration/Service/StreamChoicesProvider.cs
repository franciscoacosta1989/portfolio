﻿/* 
    Developer: Francisco Acosta
    Company: NBC Universal - The Arthouse
    File Purpose: Fetches JSON and lists property names/paths with labels.
*/

using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;
using ADMConfiguration.Data;

namespace ADMConfiguration.Service
{
    public sealed class StreamChoicesProvider
    {
        // Static HttpClient to avoid socket exhaustion
        private static readonly HttpClient _httpClient = CreateClient();

        private static HttpClient CreateClient()
        {
            var client = new HttpClient { Timeout = TimeSpan.FromSeconds(15) };
            client.DefaultRequestHeaders.Accept.Clear();
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
            client.DefaultRequestHeaders.UserAgent.ParseAdd("ADMConfiguration/1.0");
            return client;
        }

        private static async Task<(JsonDocument? Doc, string Raw)> FetchJsonAsync(
            string url,
            CancellationToken ct)
        {
            if (string.IsNullOrWhiteSpace(url))
                return (null, string.Empty);

            HttpResponseMessage resp;
            try
            {
                using var req = new HttpRequestMessage(HttpMethod.Get, url);
                resp = await _httpClient.SendAsync(req, HttpCompletionOption.ResponseHeadersRead, ct)
                                        .ConfigureAwait(false);
            }
            catch
            {
                return (null, string.Empty);
            }

            var raw = await SafeReadAsStringAsync(resp, ct).ConfigureAwait(false);

            var trimmed = raw?.TrimStart() ?? string.Empty;
            if (trimmed.Length == 0 || trimmed[0] != '{' && trimmed[0] != '[')
                return (null, raw ?? string.Empty);

            try
            {
                var doc = JsonDocument.Parse(raw!,
                    new JsonDocumentOptions
                    {
                        AllowTrailingCommas = false,
                        CommentHandling = JsonCommentHandling.Disallow
                    });
                return (doc, raw!);
            }
            catch
            {
                return (null, raw ?? string.Empty);
            }
        }

        private static async Task<string> SafeReadAsStringAsync(
            HttpResponseMessage resp,
            CancellationToken ct)
        {
            await using var stream = await resp.Content.ReadAsStreamAsync(ct).ConfigureAwait(false);

            using var ms = new MemoryStream();
            var buffer = new byte[64 * 1024];
            int read;
            while ((read = await stream.ReadAsync(buffer, 0, buffer.Length, ct).ConfigureAwait(false)) > 0)
                ms.Write(buffer, 0, read);

            var encoding = Encoding.UTF8;
            var charset = resp.Content.Headers.ContentType?.CharSet;
            if (!string.IsNullOrWhiteSpace(charset))
            {
                try { encoding = Encoding.GetEncoding(charset); } catch { /* keep UTF-8 */ }
            }

            return encoding.GetString(ms.ToArray());
        }

         public async Task<IReadOnlyList<string>> GetPropertyNamesAsync(string jsonUrl, CancellationToken cancellationToken = default)
        {
            var (doc, raw) = await FetchJsonAsync(jsonUrl, cancellationToken).ConfigureAwait(false);
            if (doc is null)
                return new[] { "(no data)" };

            try
            {
                var set = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
                Traverse(doc.RootElement, set);

                var list = set.ToList();
                list.Sort(StringComparer.OrdinalIgnoreCase);
                return list.Count == 0 ? new[] { "(no data)" } : list;
            }
            finally { doc.Dispose(); }
        }

        public async Task<IReadOnlyList<string>> GetPropertyNamesAtPathAsync(
            string jsonUrl,
            string path,
            int depth = 0,
            CancellationToken cancellationToken = default)
        {
            var (doc, raw) = await FetchJsonAsync(jsonUrl, cancellationToken).ConfigureAwait(false);
            if (doc is null)
                return new[] { "(no data)" };

            try
            {
                var nodes = ResolveNodesByPath(doc.RootElement, path);
                if (nodes.Count == 0)
                    return await GetPropertyNamesAsync(jsonUrl, cancellationToken).ConfigureAwait(false);

                var set = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
                foreach (var node in nodes)
                    CollectKeys(node, set, depth);

                var list = set.ToList();
                list.Sort(StringComparer.OrdinalIgnoreCase);

                return list.Count == 0 ? new[] { "(no data)" } : list;
            }
            finally { doc.Dispose(); }
        }

        private static void Traverse(JsonElement el, HashSet<string> acc)
        {
            switch (el.ValueKind)
            {
                case JsonValueKind.Object:
                    foreach (var prop in el.EnumerateObject())
                    {
                        acc.Add(prop.Name);
                        Traverse(prop.Value, acc);
                    }
                    break;
                case JsonValueKind.Array:
                    foreach (var item in el.EnumerateArray())
                        Traverse(item, acc);
                    break;
                default:
                    break;
            }
        }

        private static void CollectKeys(JsonElement node, HashSet<string> acc, int depth)
        {
            if (node.ValueKind != JsonValueKind.Object) return;

            foreach (var prop in node.EnumerateObject())
            {
                acc.Add(prop.Name);

                if (depth >= 1 && prop.Value.ValueKind == JsonValueKind.Object)
                {
                    foreach (var child in prop.Value.EnumerateObject())
                        acc.Add($"{prop.Name}.{child.Name}");
                }
            }
        }

        private static List<JsonElement> ResolveNodesByPath(JsonElement root, string path)
        {
            var results = new List<JsonElement> { root };
            if (string.IsNullOrWhiteSpace(path))
                return results;

            var tokens = path.Split('.', StringSplitOptions.RemoveEmptyEntries);

            foreach (var token in tokens)
            {
                var next = new List<JsonElement>();
                var isArrayToken = token.EndsWith("[]", StringComparison.Ordinal);
                var key = isArrayToken ? token.Substring(0, token.Length - 2) : token;

                foreach (var current in results)
                {
                    if (current.ValueKind != JsonValueKind.Object)
                        continue;

                    if (!current.TryGetProperty(key, out var prop))
                        continue;

                    if (isArrayToken)
                    {
                        if (prop.ValueKind == JsonValueKind.Array)
                        {
                            foreach (var item in prop.EnumerateArray())
                                next.Add(item);
                        }
                    }
                    else
                    {
                        next.Add(prop);
                    }
                }

                results = next;
                if (results.Count == 0) break;
            }

            return results;
        }


        /// Enumerates all paths with labels for any JSON
        public async Task<IReadOnlyList<ChoiceItem>> GetAllPathsAsync(string jsonUrl, int maxDepth = int.MaxValue, CancellationToken cancellationToken = default)
        {
            var (doc, raw) = await FetchJsonAsync(jsonUrl, cancellationToken).ConfigureAwait(false);
            if (doc is null)
                return new[] { new ChoiceItem { Path = "", Display = "(no data)", DisplayShort = "(no data)", Type = "unknown", Kind = ChoiceKind.Value } };
            try
            {
                var acc = new List<ChoiceItem>(capacity: 1024);
                Walk(doc.RootElement, path: "", acc, remainingDepth: maxDepth, ancestors: new List<string>());

                var list = acc
                    .GroupBy(c => c.Path, StringComparer.OrdinalIgnoreCase)
                    .Select(g => g.First())
                    .OrderBy(c => c.Path, StringComparer.OrdinalIgnoreCase)
                    .ToList();

                return list.Count == 0
                    ? new[] { new ChoiceItem { Path = "", Display = "(no data)", DisplayShort = "(no data)", Type = "unknown", Kind = ChoiceKind.Value } }
                    : list;
            }
            finally { doc.Dispose(); }
        }

        public async Task<IReadOnlyList<string>> GetAllPropertyPathsAsync(string jsonUrl, int maxDepth = int.MaxValue, CancellationToken cancellationToken = default)
        {
            var choices = await GetAllPathsAsync(jsonUrl, maxDepth, cancellationToken).ConfigureAwait(false);
            return choices.Select(c => c.Path).ToList();
        }

        private static void Walk(
            JsonElement el,
            string path,
            List<ChoiceItem> acc,
            int remainingDepth,
            List<string>? ancestors = null)
        {
            if (remainingDepth < 0) return;

            ancestors ??= new List<string>();
            var depth = ancestors.Count;
            var parentPath = ancestors.Count > 0 ? ancestors[^1] : null;

            switch (el.ValueKind)
            {
                case JsonValueKind.Object:
                    if (!string.IsNullOrEmpty(path))
                    {
                        acc.Add(new ChoiceItem
                        {
                            Path = path,
                            Display = $"{path} (object)",
                            DisplayShort = path,
                            Kind = ChoiceKind.Object,
                            Type = "object",
                            ParentPath = parentPath,
                            Ancestors = ancestors.ToArray(),
                            Depth = depth
                        });
                    }

                    foreach (var prop in el.EnumerateObject())
                    {
                        var childPath = string.IsNullOrEmpty(path) ? prop.Name : $"{path}.{prop.Name}";

                        ancestors.Add(path);
                        Walk(prop.Value, childPath, acc, remainingDepth - 1, ancestors);
                        ancestors.RemoveAt(ancestors.Count - 1);
                    }
                    break;

                case JsonValueKind.Array:
                    var arrayPath = $"{path}[]";

                    JsonElement first = default;
                    bool hasFirst = false;
                    using (var enumerator = el.EnumerateArray().GetEnumerator())
                    {
                        if (enumerator.MoveNext())
                        {
                            first = enumerator.Current;
                            hasFirst = true;
                        }
                    }

                    var kind = hasFirst && first.ValueKind == JsonValueKind.Object
                        ? ChoiceKind.ArrayObject
                        : ChoiceKind.ArrayPrimitive;

                    var arrayType = hasFirst ? $"array<{TypeString(first.ValueKind)}>" : "array<unknown>";

                    acc.Add(new ChoiceItem
                    {
                        Path = arrayPath,
                        Display = $"{arrayPath} ({arrayType})",
                        DisplayShort = arrayPath,
                        Kind = kind,
                        Type = arrayType,
                        ParentPath = parentPath,
                        Ancestors = ancestors.ToArray(),
                        Depth = depth
                    });

                    ancestors.Add(arrayPath);
                    foreach (var item in el.EnumerateArray())
                    {
                        Walk(item, arrayPath, acc, remainingDepth - 1, ancestors);
                    }
                    ancestors.RemoveAt(ancestors.Count - 1);
                    break;

                default:
                    // Leaf value (string/number/bool/null)
                    acc.Add(new ChoiceItem
                    {
                        Path = path,
                        Display = $"{path} ({TypeString(el.ValueKind)})",
                        DisplayShort = FriendlyLabelFromPath(path), // friendly short label
                        Kind = ChoiceKind.Value,
                        Type = TypeString(el.ValueKind),
                        ParentPath = parentPath,
                        Ancestors = ancestors.ToArray(),
                        Depth = depth
                    });
                    break;
            }
        }

        private static string TypeString(JsonValueKind k) => k switch
        {
            JsonValueKind.String => "string",
            JsonValueKind.Number => "number",
            JsonValueKind.True => "boolean",
            JsonValueKind.False => "boolean",
            JsonValueKind.Null => "null",
            JsonValueKind.Object => "object",
            JsonValueKind.Array => "array",
            _ => "unknown"
        };

        /// Converts a path to a friendly label
        private static string FriendlyLabelFromPath(string path)
        {
            if (string.IsNullOrWhiteSpace(path))
                return "(no data)";

            var rawTokens = path.Split('.', StringSplitOptions.RemoveEmptyEntries);
            if (rawTokens.Length == 0) return path;

            var tokens = rawTokens.Select(t => t.EndsWith("[]") ? t[..^2] : t).ToArray();
            int n = tokens.Length;
            var leaf = tokens[n - 1];

            if (n == 1) return leaf;

            bool secondIsArray = rawTokens.Length >= 2 && rawTokens[1].EndsWith("[]");

            // Root child or child of a root array item: show only leaf
            if (n == 2 || n == 3 && secondIsArray)
                return leaf;

            var parent = tokens[n - 2];
            return $"{parent}: {leaf}";
        }
    }
}
