﻿/* 
    Developer: Francisco Acosta
    Company: NBC Universal - The Arthouse
    File Purpose: Safely coordinates file access.
*/

using System.Collections.Concurrent;
using System.Runtime.InteropServices;
using System.Text;


namespace ArthouseDataManager
{
    internal static class FileIoCoordinator
    {
        private static readonly ConcurrentDictionary<string, SemaphoreSlim> _locks = new(StringComparer.OrdinalIgnoreCase);

        private const int ERROR_SHARING_VIOLATION = unchecked((int)0x80070020);
        private const int ERROR_LOCK_VIOLATION = unchecked((int)0x80070021);

        public static async Task WithFileLockAsync(string path, Func<Task> action, CancellationToken ct)
        {
            var sem = _locks.GetOrAdd(path, _ => new SemaphoreSlim(1, 1));
            await sem.WaitAsync(ct).ConfigureAwait(false);
            try
            {
                await action().ConfigureAwait(false);
            }
            finally
            {
                sem.Release();
            }
        }

        public static async Task RetryOnSharingViolationAsync(Func<Task> action, int maxAttempts, TimeSpan initialDelay, CancellationToken ct)
        {
            int attempt = 0;
            var delay = initialDelay;

            while (true)
            {
                try
                {
                    await action().ConfigureAwait(false);
                    return;
                }
                catch (IOException ioEx) when (IsSharingViolation(ioEx))
                {
                    attempt++;
                    if (attempt >= maxAttempts)
                        throw;

                    await Task.Delay(delay, ct).ConfigureAwait(false);

                    var ms = Math.Min((int)(delay.TotalMilliseconds * 1.7), 4000);
                    delay = TimeSpan.FromMilliseconds(ms + Random.Shared.Next(0, 250));
                }
            }
        }

        public static bool IsSharingViolation(IOException ex)
        {
            int hresult = Marshal.GetHRForException(ex);
            return hresult == ERROR_SHARING_VIOLATION || hresult == ERROR_LOCK_VIOLATION;
        }

        public static StreamReader CreateReaderWithShare(string path)
        {
            var fs = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite);
            return new StreamReader(fs, new UTF8Encoding(false));
        }
    }
}
