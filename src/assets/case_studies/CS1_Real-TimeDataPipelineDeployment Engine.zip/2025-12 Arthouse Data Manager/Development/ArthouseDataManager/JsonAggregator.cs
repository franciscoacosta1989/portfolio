﻿/* 
    Developer: Francisco Acosta
    Company: NBC Universal - The Arthouse
    File Purpose: Turns JSON paths into rows.
*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json;

namespace ArthouseDataManager
{
    internal static class JsonAggregator
    {
        public static IReadOnlyList<string[]> AggregateRows(JsonElement root, IReadOnlyList<string> selectedPaths)
        {
            var paths = selectedPaths.Where(p => !string.IsNullOrWhiteSpace(p)).ToList();
            if (paths.Count == 0)
                return Array.Empty<string[]>();

            var arrayRoot = FindDeepestArrayRoot(paths);

            if (string.IsNullOrEmpty(arrayRoot))
            {
                var oneRow = paths.Select(p => GetByFullPath(root, p)).ToArray();
                return new[] { oneRow };
            }

            var nodes = ResolveNodes(root, arrayRoot);
            if (nodes.Count == 0)
                return Array.Empty<string[]>();

            var tails = paths.Select(p =>
            {
                if (p.StartsWith(arrayRoot + ".", StringComparison.OrdinalIgnoreCase))
                    return p[(arrayRoot.Length + 1)..];
                if (string.Equals(p, arrayRoot, StringComparison.OrdinalIgnoreCase))
                    return string.Empty;
                return null;
            }).ToList();

            var rows = new List<string[]>(capacity: nodes.Count);
            foreach (var node in nodes)
            {
                var cols = new List<string>(paths.Count);
                for (int i = 0; i < paths.Count; i++)
                {
                    var tail = tails[i];
                    if (tail is null)
                    {
                        cols.Add(GetByFullPath(root, paths[i]));
                    }
                    else
                    {
                        cols.Add(GetScalar(node, tail));
                    }
                }
                rows.Add(cols.ToArray());
            }
            return rows;
        }

        public static string FindDeepestArrayRoot(IReadOnlyList<string> paths)
        {
            var candidates = paths
                .Select(p =>
                {
                    var parts = p.Split('.', StringSplitOptions.RemoveEmptyEntries);
                    var idxs = parts.Select((tok, i) => (tok, i))
                                    .Where(x => x.tok.EndsWith("[]", StringComparison.Ordinal))
                                    .Select(x => x.i)
                                    .ToArray();
                    return idxs.Length == 0 ? null : string.Join('.', parts.Take(idxs.Last() + 1));
                })
                .Where(s => !string.IsNullOrWhiteSpace(s))
                .ToList();

            if (candidates.Count == 0) return string.Empty;

            candidates = candidates.OrderByDescending(c => c.Split('.').Length).ToList();
            foreach (var c in candidates)
                if (paths.All(p => p.StartsWith(c, StringComparison.OrdinalIgnoreCase) || p.Contains(c, StringComparison.OrdinalIgnoreCase)))
                    return c;

            return candidates[0]!;
        }

        public static List<JsonElement> ResolveNodes(JsonElement root, string path)
        {
            var results = new List<JsonElement> { root };
            if (string.IsNullOrWhiteSpace(path)) return results;

            var tokens = path.Split('.', StringSplitOptions.RemoveEmptyEntries);

            foreach (var token in tokens)
            {
                var next = new List<JsonElement>();
                var isArrayToken = token.EndsWith("[]", StringComparison.Ordinal);
                var key = isArrayToken ? token[..^2] : token;

                foreach (var current in results)
                {
                    if (current.ValueKind != JsonValueKind.Object) continue;
                    if (!current.TryGetProperty(key, out var prop)) continue;

                    if (isArrayToken)
                    {
                        if (prop.ValueKind == JsonValueKind.Array)
                            foreach (var item in prop.EnumerateArray())
                                next.Add(item);
                    }
                    else
                    {
                        next.Add(prop);
                    }
                }

                results = next;
                if (results.Count == 0) break;
            }

            return results;
        }

        public static string GetScalar(JsonElement node, string relativePath)
        {
            if (string.IsNullOrWhiteSpace(relativePath))
                return ScalarToString(node);

            var tokens = relativePath.Split('.', StringSplitOptions.RemoveEmptyEntries);
            var cur = node;

            foreach (var t in tokens)
            {
                if (cur.ValueKind != JsonValueKind.Object) return string.Empty;
                if (!cur.TryGetProperty(t, out cur)) return string.Empty;
            }

            return ScalarToString(cur);
        }

        public static string GetByFullPath(JsonElement root, string fullPath)
        {
            if (string.IsNullOrWhiteSpace(fullPath)) return string.Empty;

            var tokens = fullPath.Split('.', StringSplitOptions.RemoveEmptyEntries);
            var nodes = new List<JsonElement> { root };

            foreach (var token in tokens)
            {
                var next = new List<JsonElement>();
                var isArrayToken = token.EndsWith("[]", StringComparison.Ordinal);
                var key = isArrayToken ? token[..^2] : token;

                foreach (var node in nodes)
                {
                    if (node.ValueKind != JsonValueKind.Object) continue;
                    if (!node.TryGetProperty(key, out var prop)) continue;

                    if (isArrayToken)
                    {
                        if (prop.ValueKind == JsonValueKind.Array)
                            foreach (var item in prop.EnumerateArray())
                                next.Add(item);
                    }
                    else
                    {
                        next.Add(prop);
                    }
                }

                nodes = next;
                if (nodes.Count == 0) break;
            }

            if (nodes.Count == 0) return string.Empty;

            var scalars = nodes.Select(ScalarToString).Where(s => !string.IsNullOrEmpty(s)).ToArray();
            return scalars.Length == 0 ? string.Empty : string.Join("|", scalars);
        }

        private static string ScalarToString(JsonElement el) => el.ValueKind switch
        {
            JsonValueKind.String => el.GetString() ?? string.Empty,
            JsonValueKind.Number => el.TryGetInt64(out var i) ? i.ToString()
                                    : el.TryGetDouble(out var d) ? d.ToString("G")
                                    : el.GetRawText(),
            JsonValueKind.True => "true",
            JsonValueKind.False => "false",
            JsonValueKind.Null => string.Empty,
            JsonValueKind.Object => el.GetRawText(),
            JsonValueKind.Array => el.GetRawText(),
            _ => string.Empty
        };
    }
}
