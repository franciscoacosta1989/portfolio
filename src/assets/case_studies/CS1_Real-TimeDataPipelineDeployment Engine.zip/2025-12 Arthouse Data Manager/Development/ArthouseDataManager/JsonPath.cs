﻿/* 
    Developer: Francisco Acosta
    Company: NBC Universal - The Arthouse
    File Purpose: Navigates JSON paths, extracts values, finds deepest array root.
*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json;

namespace ArthouseDataManager
{
    internal static class JsonPath
    {
        public static List<JsonElement> ResolveNodes(JsonElement root, string path)
        {
            var results = new List<JsonElement> { root };
            if (string.IsNullOrWhiteSpace(path)) return results;

            var tokens = path.Split('.', StringSplitOptions.RemoveEmptyEntries);

            foreach (var token in tokens)
            {
                var next = new List<JsonElement>();
                var isArrayToken = token.EndsWith("[]", StringComparison.Ordinal);
                var key = isArrayToken ? token[..^2] : token;

                foreach (var current in results)
                {
                    if (current.ValueKind != JsonValueKind.Object) continue;
                    if (!current.TryGetProperty(key, out var prop)) continue;

                    if (isArrayToken)
                    {
                        if (prop.ValueKind == JsonValueKind.Array)
                        {
                            foreach (var item in prop.EnumerateArray())
                                next.Add(item);
                        }
                    }
                    else
                    {
                        next.Add(prop);
                    }
                }

                results = next;
                if (results.Count == 0) break;
            }

            return results;
        }

        public static string GetScalar(JsonElement node, string relativePath)
        {
            if (string.IsNullOrWhiteSpace(relativePath))
                return ScalarToString(node);

            var tokens = relativePath.Split('.', StringSplitOptions.RemoveEmptyEntries);
            var cur = node;

            foreach (var t in tokens)
            {
                if (cur.ValueKind != JsonValueKind.Object) return string.Empty;
                if (!cur.TryGetProperty(t, out cur)) return string.Empty;
            }

            return ScalarToString(cur);
        }

        private static string ScalarToString(JsonElement el) => el.ValueKind switch
        {
            JsonValueKind.String => el.GetString() ?? string.Empty,
            JsonValueKind.Number => el.TryGetInt64(out var i) ? i.ToString()
                                    : el.TryGetDouble(out var d) ? d.ToString("G")
                                    : el.GetRawText(),
            JsonValueKind.True => "true",
            JsonValueKind.False => "false",
            JsonValueKind.Null => string.Empty,
            JsonValueKind.Object => el.GetRawText(),
            JsonValueKind.Array => el.GetRawText(),
            _ => string.Empty
        };

        public static string FindDeepestArrayRoot(IReadOnlyList<string> paths)
        {
            var candidates = paths
                .Select(p =>
                {
                    var parts = p.Split('.', StringSplitOptions.RemoveEmptyEntries);
                    var indices = parts
                        .Select((tok, idx) => (tok, idx))
                        .Where(x => x.tok.EndsWith("[]", StringComparison.Ordinal))
                        .Select(x => x.idx)
                        .ToArray();
                    return indices.Length == 0 ? null : string.Join('.', parts.Take(indices.Last() + 1));
                })
                .Where(s => !string.IsNullOrWhiteSpace(s))
                .ToList();

            if (candidates.Count == 0) return string.Empty;

            candidates = candidates.OrderByDescending(c => c!.Split('.').Length).ToList();
            foreach (var c in candidates)
            {
                if (paths.All(p => p.StartsWith(c!, StringComparison.OrdinalIgnoreCase) || p.Contains(c!, StringComparison.OrdinalIgnoreCase)))
                    return c!;
            }
            return candidates[0]!;
        }
    }
}
