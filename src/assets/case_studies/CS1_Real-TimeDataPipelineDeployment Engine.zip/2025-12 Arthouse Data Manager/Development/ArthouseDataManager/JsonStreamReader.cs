﻿/* 
    Developer: Francisco Acosta
    Company: NBC Universal - The Arthouse
    File Purpose: Reads json url
*/

using System.Text.Json;

public class JsonStreamReader
{
    // Use a static HttpClient for performance and to avoid socket exhaustion
    private static readonly HttpClient _httpClient = new HttpClient();

    /// Fetches a JSON document from the given URL.
    /// Doc will be null if the response isn't valid JSON or parsing fails.
    /// Raw is always a non-null string.

    public async Task<(JsonDocument? Doc, string Raw)> FetchJsonAsync(string url)
    {
        if (string.IsNullOrWhiteSpace(url))
            return (null, string.Empty);

        string raw;
        try
        {
            raw = await _httpClient.GetStringAsync(url).ConfigureAwait(false);
        }
        catch
        {
            // Network or HTTP failure
            return (null, string.Empty);
        }

        raw ??= string.Empty;
        var trimmed = raw.TrimStart();

         if (!trimmed.StartsWith("{") && !trimmed.StartsWith("["))
        {
            return (null, raw);
        }

        try
        {
            var doc = JsonDocument.Parse(raw);
            return (doc, raw);
        }
        catch
        {
            return (null, raw);
        }
    }
}
