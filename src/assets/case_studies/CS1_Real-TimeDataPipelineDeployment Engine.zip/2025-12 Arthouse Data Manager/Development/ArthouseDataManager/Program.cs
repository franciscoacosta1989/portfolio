/* 
    Developer: Francisco Acosta
    Company: NBC Universal - The Arthouse
    File Purpose: Runs the windows service and starts RealTimeDataHostedService
*/

using ADMConfiguration.Configuration;

namespace ArthouseDataManager
{
    public static class Program
    {
        public static void Main(string[] args)
        {
            Host.CreateDefaultBuilder(args)
                .UseWindowsService(options =>
                {
                    options.ServiceName = "ArthouseDataManager";
                })
                .ConfigureServices((ctx, services) =>
                {
                    services.AddSingleton<ServiceLogger>();
                    services.AddSingleton<RealTimeDataService>();

                    var cfgPath = ctx.Configuration["ConfigPath"]
                                  ?? ActiveConfigPointer.DefaultPointerPath;

                    services.AddHostedService(sp =>
                        new RealTimeDataHostedService(
                            sp.GetRequiredService<RealTimeDataService>(),
                            sp.GetRequiredService<ServiceLogger>(),
                            cfgPath));
                })
                .Build()
                .Run();
        }
    }
}
