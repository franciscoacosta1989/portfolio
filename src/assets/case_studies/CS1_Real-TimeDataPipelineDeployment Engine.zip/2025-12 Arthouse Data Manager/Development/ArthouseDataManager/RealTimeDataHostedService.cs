﻿/* 
    Developer: Francisco Acosta
    Company: NBC Universal - The Arthouse
    File Purpose: Defines windows service that starts and stops RealTimeDataService using a config file path
*/

using ADMConfiguration.Configuration;

namespace ArthouseDataManager
{
    public sealed class RealTimeDataHostedService : IHostedService
    {
        private readonly RealTimeDataService _dataService;
        private readonly ServiceLogger _logger;
        private readonly string _configPath;

        private Task? _startupTask;

        public RealTimeDataHostedService(RealTimeDataService dataService, ServiceLogger logger, string configPath)
        {
            _dataService = dataService ?? throw new ArgumentNullException(nameof(dataService));
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
            _configPath = string.IsNullOrWhiteSpace(configPath)
                ? @"C:\ArthouseDataManager\Config\config.json"
                : configPath;
        }


        public Task StartAsync(CancellationToken cancellationToken)
        {
            _logger.LogInfo("Service", $"Hosted Service starting... Raw ConfigPath='{_configPath}'");

            _startupTask = Task.Run(async () =>
            {
                try
                {
                    string effectivePath = _configPath;
                    if (Path.GetFileName(_configPath)
                            .Equals("active.json", StringComparison.OrdinalIgnoreCase))
                    {
                        effectivePath = ActiveConfigPointer.ReadTargetPath(_configPath);
                    }
                    else
                    {
                        var defaultPointer = ActiveConfigPointer.DefaultPointerPath;
                        if (File.Exists(defaultPointer))
                            effectivePath = ActiveConfigPointer.ReadTargetPath(defaultPointer);
                    }

                    _logger.LogInfo("Service", $"Effective ConfigPath='{effectivePath}'");
                    await _dataService.StartAsync(effectivePath).ConfigureAwait(false);
                    _logger.LogInfo("Service", "Service started successfully.");
                }
                catch (Exception ex)
                {
                    _logger.LogError("Service", $"Service failed to start: {ex.Message}", ex);
                    throw;
                }
            }, cancellationToken);

            return Task.CompletedTask;
        }


        public Task StopAsync(CancellationToken cancellationToken)
        {
            _logger.LogInfo("Service", "Hosted Service stopping...");
            try
            {
                _dataService.Stop();
                _logger.LogInfo("Service", "Hosted Service stopped.");
            }
            catch (Exception ex)
            {
                _logger.LogError("Service", $"Error during stop: {ex.Message}", ex);
            }

            return Task.CompletedTask;
        }
    }
}
