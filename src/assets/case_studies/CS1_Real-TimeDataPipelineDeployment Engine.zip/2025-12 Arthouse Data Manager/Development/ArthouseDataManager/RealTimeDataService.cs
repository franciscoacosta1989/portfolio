﻿/* 
    Developer: Francisco Acosta
    Company: NBC Universal - The Arthouse
    File Purpose: Loads configuration file, starts stream processors, and stops them when service ends.
*/

using ADMConfiguration.Configuration;

namespace ArthouseDataManager
{
    public class RealTimeDataService
    {
        private readonly ServiceLogger _logger;
        private readonly List<StreamProcessor> _processors = new();
        private StreamManager _config = new();

        public RealTimeDataService(ServiceLogger logger)
        {
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        }

        public async Task StartAsync(string configPath = @"C:\ArthouseDataManager\Config\config.json")
        {
            _logger.LogInfo("Service", $"Service starting… ConfigPath='{configPath}'");

            try
            {
                _config = await ConfigManager.LoadConfigAsync(configPath).ConfigureAwait(false);
            }
            catch (Exception ex)
            {
                _logger.LogError("Service", $"Failed to load config: {ex.Message}");
                throw;
            }

            foreach (var stream in _config.Streams)
            {
                var processor = new StreamProcessor(stream, _logger);
                _processors.Add(processor);
                processor.Start();
            }

            _logger.LogInfo("Service", $"Service started. Workers={_processors.Count}");
        }

        public void Start() => StartAsync().GetAwaiter().GetResult();

        public void Stop()
        {
            _logger.LogInfo("Service", "Service stopping…");
            foreach (var processor in _processors)
            {
                try { processor.Stop(); }
                catch (Exception ex) { _logger.LogError("Service", $"Processor stop error: {ex.Message}"); }
            }
            _processors.Clear();
            _logger.LogInfo("Service", "Service stopped.");
        }
    }
}
