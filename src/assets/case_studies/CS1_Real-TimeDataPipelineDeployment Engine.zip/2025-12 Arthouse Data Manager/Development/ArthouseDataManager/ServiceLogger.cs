﻿/* 
    Developer: Francisco Acosta
    Company: NBC Universal - The Arthouse
    File Purpose: Logs information and errors to file for each stream
*/

using System;
using System.Collections.Concurrent;
using System.IO;
using System.Text;

public class ServiceLogger
{
    // Root folder for all logs
    private readonly string _baseLogPath = @"C:\ArthouseDataManager\Logs";

    private static readonly ConcurrentDictionary<string, object> _fileLocks = new();

    public ServiceLogger()
    {
        try
        {
            Directory.CreateDirectory(_baseLogPath);
        }
        catch
        {
            // Silent fail to keep the service alive even if the directory cannot be created here
        }
    }

    /// Informational message: written to for each streams log file inside the stream's folder.

    public void LogInfo(string streamName, string message)
    {
        Log(streamName, "INFO", message);
    }

    /// Error message: written for each streams log file inside the stream's folder.
        public void LogError(string streamName, string message, Exception? ex = null)
    {
        var full = ex is null ? message : $"{message} {ex.Message}";
        Log(streamName, "ERROR", full);
    }

    /// Writes a structured error entry to a dedicated per-stream error file


    public void WriteErrorFile(string streamName, string message, Exception? ex = null, string? rawResponse = null)
    {
        try
        {
            var safeName = SanitizeFileName(streamName);
            if (string.IsNullOrWhiteSpace(safeName))
                safeName = "unnamed";

            // Each streams folder
            var perStreamDir = Path.Combine(_baseLogPath, safeName);
            Directory.CreateDirectory(perStreamDir);

            // Required file name with "_error" after stream name
            var errorPath = Path.Combine(perStreamDir, $"{safeName}_error.txt");

            // Breadcrumb into the regular log so you can verify runtime path
            LogInfo(safeName, $"[ServiceLogger] Writing error file to: {errorPath}");

            var sb = new StringBuilder();
            sb.Append($"{DateTime.UtcNow:u} - {message}");
            if (ex is not null) sb.Append($" Exception: {ex.Message}");
            sb.AppendLine();

            if (!string.IsNullOrEmpty(rawResponse))
            {
                sb.AppendLine("Raw Response:");
                sb.AppendLine(rawResponse);
                sb.AppendLine();
            }

            AppendAllTextThreadSafe(errorPath, sb.ToString());
        }
        catch
        {
            // Silent fail to avoid crashing the service
        }
    }

    /// Writes to each streams log file inside the stream's folder.
    /// Removes any legacy "log.txt" in the same folder to prevent duplicates.
    private void Log(string streamName, string level, string message)
    {
        try
        {
            var safeName = SanitizeFileName(streamName);
            if (string.IsNullOrWhiteSpace(safeName))
                safeName = "unnamed";

            var perStreamDir = Path.Combine(_baseLogPath, safeName);
            Directory.CreateDirectory(perStreamDir);

            // Consistent naming: "{StreamName}_log.txt"
            var logPath = Path.Combine(perStreamDir, $"{safeName}_log.txt");
            var line = $"{DateTime.Now:u} [{level}] {message}{Environment.NewLine}";

            // Remove any legacy "log.txt" that might be created by old code
            var legacyLogPath = Path.Combine(perStreamDir, "log.txt");
            TryDeleteLegacyLog(legacyLogPath);

            AppendAllTextThreadSafe(logPath, line);
        }
        catch
        {
            // Silent fail
        }
    }

    private static void TryDeleteLegacyLog(string legacyPath)
    {
        try
        {
            if (File.Exists(legacyPath))
            {
                File.Delete(legacyPath);
            }
        }
        catch
        {
            // If deletion fails due to locks/permissions, ignore safely
        }
    }

    /// Thread-safe append using a dedicated lock per file path.
    private static void AppendAllTextThreadSafe(string path, string content)
    {
        var dir = Path.GetDirectoryName(path);
        if (!string.IsNullOrEmpty(dir))
            Directory.CreateDirectory(dir);

        var lockObj = _fileLocks.GetOrAdd(path, _ => new object());
        lock (lockObj)
        {
            File.AppendAllText(path, content, new UTF8Encoding(encoderShouldEmitUTF8Identifier: false));
        }
    }

    /// Replaces invalid filename characters with underscores and trims whitespace.
    private static string SanitizeFileName(string? name)
    {
        if (string.IsNullOrWhiteSpace(name)) return string.Empty;
        foreach (var c in Path.GetInvalidFileNameChars())
            name = name.Replace(c, '_');
        return name.Trim();
    }
}
