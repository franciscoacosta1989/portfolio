﻿/* 
    Developer: Francisco Acosta
    Company: NBC Universal - The Arthouse
    File Purpose: Fetches JSON, extracts data, writes to files repeatedly.
*/

using System.Text.Json;

using ADMConfiguration.Data;

namespace ArthouseDataManager
{
    public sealed class StreamProcessor
    {
        private readonly DataStream _stream;
        private readonly ServiceLogger _logger;
        private readonly JsonStreamReader _reader = new();
        private CancellationTokenSource? _cts;
        private Task? _loop;

        public StreamProcessor(DataStream stream, ServiceLogger logger)
        {
            _stream = stream ?? throw new ArgumentNullException(nameof(stream));
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        }

        public void Start()
        {
            if (_loop is not null) return;
            _cts = new CancellationTokenSource();
            _loop = Task.Run(() => PollLoopAsync(_cts.Token));
        }

        public void Stop()
        {
            try
            {
                _cts?.Cancel();
                _loop?.Wait(TimeSpan.FromSeconds(5));
            }
            catch { }
            finally
            {
                _cts?.Dispose();
                _cts = null;
                _loop = null;
            }
        }

        private async Task PollLoopAsync(CancellationToken ct)
        {
            var name = string.IsNullOrWhiteSpace(_stream.Name) ? "(unnamed)" : _stream.Name;

            // Fallback: if IntervalSeconds is null, use 30; ensure minimum of 1 second
            int intervalSeconds = Math.Max(1, _stream.IntervalSeconds ?? 30);

            _logger.LogInfo(name, $"Poll loop starting. Interval={intervalSeconds}s Url='{_stream.JsonUrl}'");

            while (!ct.IsCancellationRequested)
            {
                try
                {
                    if (string.IsNullOrWhiteSpace(_stream.JsonUrl))
                    {
                        _logger.LogInfo(name, "JsonUrl is empty; skipping this cycle.");
                    }
                    else
                    {
                        var (doc, raw) = await _reader.FetchJsonAsync(_stream.JsonUrl);
                        if (doc is null)
                        {
                            _logger.LogError(name, "FetchJsonAsync failed (network or parse error). Raw response captured.");
                            _logger.WriteErrorFile(name, "Invalid JSON format or fetch error.", null, raw);
                        }
                        else
                        {
                            var selectedPaths = (_stream.SelectedObjects?.Where(p => !string.IsNullOrWhiteSpace(p)).ToList()
                                                ?? new List<string>());

                            if (selectedPaths.Count == 0 && !string.IsNullOrWhiteSpace(_stream.SelectedObject))
                            {
                                selectedPaths.Add(_stream.SelectedObject);
                                _logger.LogInfo(name, "SelectedObjects empty; using legacy SelectedObject fallback.");
                            }

                            selectedPaths = selectedPaths
                                .Select(p => p.Trim())
                                .Where(p => !string.IsNullOrWhiteSpace(p))
                                .Distinct(StringComparer.OrdinalIgnoreCase)
                                .ToList();

                            var rows = AggregateRows(doc.RootElement, selectedPaths);

                            var columnDelimiter = string.IsNullOrWhiteSpace(_stream.Delimiter) ? "|" : _stream.Delimiter;
                            var perColumnDelims = _stream.SelectedDelimiters ?? new System.Collections.ObjectModel.ObservableCollection<string>();
                            var headers = _stream.SelectedHeaders ?? new System.Collections.ObjectModel.ObservableCollection<string>();

                            var outputDir = string.IsNullOrWhiteSpace(_stream.FileLocation)
                                            ? @"C:\ArthouseDataManager\Streams"
                                            : _stream.FileLocation;

                            var tempDir = string.IsNullOrWhiteSpace(_stream.TemporaryDirectory) ? @"C:\ArthouseDataManager\Temp" : _stream.TemporaryDirectory;
                            var stateDir = string.IsNullOrWhiteSpace(_stream.StateDirectory) ? @"C:\ArthouseDataManager\State" : _stream.StateDirectory;

                            Directory.CreateDirectory(outputDir);
                            Directory.CreateDirectory(tempDir);
                            Directory.CreateDirectory(stateDir);

                            var currentPath = Path.Combine(tempDir, $"{SanitizeFileName(name)}_current.txt");
                            var statePath = Path.Combine(stateDir, $"{SanitizeFileName(name)}_state.txt");
                            var outputPath = Path.Combine(outputDir, $"{SanitizeFileName(name)}.txt");

                            _logger.LogInfo(name, $"Paths resolved: Current='{currentPath}' State='{statePath}' Output='{outputPath}'");

                            // 1) Current: always overwrite
                            await ThreeFileWriter.WriteCurrentAsync(
                                currentPath,
                                rows,
                                columnDelimiter,
                                headers,
                                perColumnDelims,
                                ct);

                            // 2) State: carry forward non-empty changes
                            if (!File.Exists(statePath))
                                await ThreeFileWriter.CopyRawAsync(currentPath, statePath, ct);

                            await ThreeFileWriter.UpdateStateFromCurrentAsync(
                                statePath,
                                currentPath,
                                columnDelimiter,
                                ct);

                            // 3) Output: sync from state; always ensure output exists
                            if (!File.Exists(outputPath))
                                await ThreeFileWriter.CopyRawAsync(statePath, outputPath, ct);

                            await ThreeFileWriter.SyncOutputFromStateAsync(
                                outputPath,
                                statePath,
                                columnDelimiter,
                                ct);

                            _logger.LogInfo(
                                name,
                                $"Three-file update complete. Output='{outputPath}' Exists={File.Exists(outputPath)} Size={(File.Exists(outputPath) ? new FileInfo(outputPath).Length : 0)} bytes Rows={rows.Count}");

                            if (rows.Count == 0)
                                _logger.LogInfo(name, "No rows produced. Check SelectedObjects paths and JSON shape.");

                            doc.Dispose();
                        }
                    }
                }
                catch (OperationCanceledException) {  }
                catch (IOException ioEx)
                {
                    _logger.LogError(name, $"IO error: {ioEx.Message}", ioEx);
                    _logger.WriteErrorFile(name, "IO error", ioEx, null);
                }
                catch (Exception ex)
                {
                    _logger.LogError(name, $"General error occurred Exception: {ex.Message}", ex);
                    _logger.WriteErrorFile(name, "General error occurred", ex, null);
                }

                try
                {
                    await Task.Delay(TimeSpan.FromSeconds(intervalSeconds), ct);
                }
                catch (OperationCanceledException) { break; }

                // Refresh interval each loop in case UI changed it; keep minimum of 1 sec
                intervalSeconds = Math.Max(1, _stream.IntervalSeconds ?? 30);
            }

            _logger.LogInfo(name, "Poll loop stopped.");
        }

        private static IReadOnlyList<string[]> AggregateRows(JsonElement root, IReadOnlyList<string> selectedPaths)
        {
            var paths = selectedPaths.Where(p => !string.IsNullOrWhiteSpace(p)).ToList();
            if (paths.Count == 0)
                return Array.Empty<string[]>();

            var arrayRoot = FindDeepestArrayRoot(paths);

            if (string.IsNullOrEmpty(arrayRoot))
            {
                var oneRow = paths.Select(p => GetByFullPath(root, p)).ToArray();
                return new[] { oneRow };
            }

            var nodes = ResolveNodes(root, arrayRoot);
            if (nodes.Count == 0)
                return Array.Empty<string[]>();

            var tails = paths.Select(p =>
            {
                if (p.StartsWith(arrayRoot + ".", StringComparison.OrdinalIgnoreCase))
                    return p[(arrayRoot.Length + 1)..];
                if (string.Equals(p, arrayRoot, StringComparison.OrdinalIgnoreCase))
                    return string.Empty;
                return null;
            }).ToList();

            var rows = new List<string[]>(capacity: nodes.Count);
            foreach (var node in nodes)
            {
                var cols = new List<string>(paths.Count);
                for (int i = 0; i < paths.Count; i++)
                {
                    var tail = tails[i];
                    if (tail is null)
                        cols.Add(GetByFullPath(root, paths[i]));
                    else
                        cols.Add(GetScalar(node, tail));
                }
                rows.Add(cols.ToArray());
            }
            return rows;
        }

        private static string FindDeepestArrayRoot(IReadOnlyList<string> paths)
        {
            var candidates = paths
                .Select(p =>
                {
                    var parts = p.Split('.', StringSplitOptions.RemoveEmptyEntries);
                    var arrayIndices = parts.Select((tok, idx) => (tok, idx))
                                            .Where(x => x.tok.EndsWith("[]", StringComparison.Ordinal))
                                            .Select(x => x.idx)
                                            .ToArray();
                    return arrayIndices.Length == 0 ? null : string.Join('.', parts.Take(arrayIndices.Last() + 1));
                })
                .Where(s => !string.IsNullOrWhiteSpace(s))
                .ToList();

            if (candidates.Count == 0) return string.Empty;
            candidates = candidates.OrderByDescending(c => c!.Split('.').Length).ToList();
            foreach (var c in candidates)
                if (paths.All(p => p.StartsWith(c!, StringComparison.OrdinalIgnoreCase) || p.Contains(c!, StringComparison.OrdinalIgnoreCase)))
                    return c!;
            return candidates[0]!;
        }

        private static List<JsonElement> ResolveNodes(JsonElement root, string path)
        {
            var results = new List<JsonElement> { root };
            if (string.IsNullOrWhiteSpace(path)) return results;
            var tokens = path.Split('.', StringSplitOptions.RemoveEmptyEntries);

            foreach (var token in tokens)
            {
                var next = new List<JsonElement>();
                var isArrayToken = token.EndsWith("[]", StringComparison.Ordinal);
                var key = isArrayToken ? token[..^2] : token;

                foreach (var current in results)
                {
                    if (current.ValueKind != JsonValueKind.Object) continue;
                    if (!current.TryGetProperty(key, out var prop)) continue;

                    if (isArrayToken && prop.ValueKind == JsonValueKind.Array)
                    {
                        foreach (var item in prop.EnumerateArray())
                            next.Add(item);
                    }
                    else if (!isArrayToken)
                    {
                        next.Add(prop);
                    }
                }

                results = next;
                if (results.Count == 0) break;
            }
            return results;
        }

        private static string GetScalar(JsonElement node, string relativePath)
        {
            if (string.IsNullOrWhiteSpace(relativePath))
                return ScalarToString(node);
            var tokens = relativePath.Split('.', StringSplitOptions.RemoveEmptyEntries);
            var cur = node;
            foreach (var t in tokens)
            {
                if (cur.ValueKind != JsonValueKind.Object) return string.Empty;
                if (!cur.TryGetProperty(t, out cur)) return string.Empty;
            }
            return ScalarToString(cur);
        }

        private static string GetByFullPath(JsonElement root, string fullPath)
        {
            if (string.IsNullOrWhiteSpace(fullPath)) return string.Empty;

            var tokens = fullPath.Split('.', StringSplitOptions.RemoveEmptyEntries);
            var nodes = new List<JsonElement> { root };

            foreach (var token in tokens)
            {
                var next = new List<JsonElement>();
                var isArrayToken = token.EndsWith("[]", StringComparison.Ordinal);
                var key = isArrayToken ? token[..^2] : token;

                foreach (var node in nodes)
                {
                    if (node.ValueKind != JsonValueKind.Object) continue;
                    if (!node.TryGetProperty(key, out var prop)) continue;

                    if (isArrayToken && prop.ValueKind == JsonValueKind.Array)
                        foreach (var item in prop.EnumerateArray()) next.Add(item);
                    else if (!isArrayToken)
                        next.Add(prop);
                }

                nodes = next;
                if (nodes.Count == 0) break;
            }

            if (nodes.Count == 0) return string.Empty;

            var scalars = nodes.Select(ScalarToString).Where(s => !string.IsNullOrEmpty(s)).ToArray();
            return scalars.Length == 0 ? string.Empty : string.Join("|", scalars);
        }

        private static string ScalarToString(JsonElement el) => el.ValueKind switch
        {
            JsonValueKind.String => el.GetString() ?? string.Empty,
            JsonValueKind.Number => el.TryGetInt64(out var i) ? i.ToString()
                                    : el.TryGetDouble(out var d) ? d.ToString("G")
                                    : el.GetRawText(),
            JsonValueKind.True => "true",
            JsonValueKind.False => "false",
            JsonValueKind.Null => string.Empty,
            JsonValueKind.Object => el.GetRawText(),
            JsonValueKind.Array => el.GetRawText(),
            _ => string.Empty
        };

        private static string SanitizeFileName(string s)
        {
            foreach (var c in Path.GetInvalidFileNameChars()) s = s.Replace(c, '_');
            return s;
        }
    }
}
