﻿/* 
    Developer: Francisco Acosta
    Company: NBC Universal - The Arthouse
    File Purpose: Output json url txt file, last known data txt file and current data streams txt file
*/

using System.Text;

namespace ArthouseDataManager
{
    internal static class ThreeFileWriter
    {
        private static readonly TimeSpan InitialDelay = TimeSpan.FromMilliseconds(150);
        private const int MaxAttempts = 10;

        // FILE 1 (Current): Always overwrite
        public static async Task WriteCurrentAsync(
            string currentPath,
            IReadOnlyList<string[]> rowsBaseColumns,
            string delimiter,
            IReadOnlyList<string>? headers,
            IReadOnlyList<string>? betweenDelims,
            CancellationToken ct)
        {
            EnsureDirectory(currentPath);
            var mergedHeaders = BuildMergedHeaderCells(headers, betweenDelims);
            var mergedRows = BuildMergedRows(rowsBaseColumns, betweenDelims, minColCount: mergedHeaders.Length);

            await FileIoCoordinator.WithFileLockAsync(currentPath, async () =>
            {
                await FileIoCoordinator.RetryOnSharingViolationAsync(async () =>
                {
                    await WriteFileCoreAsync(currentPath, delimiter, mergedHeaders, mergedRows, ct);
                }, MaxAttempts, InitialDelay, ct);
            }, ct);
        }

        // FILE 2 (State): Only update cells where FILE 1 has non-empty

        public static async Task UpdateStateFromCurrentAsync(
            string statePath,
            string currentPath,
            string delimiter,
            CancellationToken ct)
        {
            EnsureDirectory(statePath);

            var (stateHeaders, stateRows) = ReadSnapshotSafe(statePath, delimiter);
            var (currentHeaders, currentRows) = ReadSnapshotSafe(currentPath, delimiter);

            // If current parsing failed but file exists, copy raw current -> state
            if (currentHeaders is null)
            {
                if (File.Exists(currentPath))
                    await CopyRawAsync(currentPath, statePath, ct);
                return;
            }

            // Initialize state if missing
            if (stateHeaders is null)
            {
                await CopyRawAsync(currentPath, statePath, ct);
                return;
            }

            bool headersMatch = ArraysEqual(stateHeaders!, currentHeaders!);
            if (!headersMatch)
            {
                await CopyRawAsync(currentPath, statePath, ct);
                return;
            }

            // Headers match → lock structure to STATE and apply non-empty updates from CURRENT
            int lockedRowCount = stateRows.Count;
            int lockedColCount = stateHeaders!.Length;

            var updatedRows = new List<string[]>(lockedRowCount);
            for (int i = 0; i < lockedRowCount; i++)
            {
                var prev = i < stateRows.Count ? stateRows[i] : new string[lockedColCount];
                var cur = i < currentRows.Count ? currentRows[i] : new string[lockedColCount];

                var outRow = new string[lockedColCount];
                for (int c = 0; c < lockedColCount; c++)
                {
                    var curVal = c < cur.Length ? cur[c] : string.Empty;
                    var prevVal = c < prev.Length ? prev[c] : string.Empty;
                    outRow[c] = string.IsNullOrWhiteSpace(curVal) ? prevVal : curVal;
                }
                updatedRows.Add(outRow);
            }

            await FileIoCoordinator.WithFileLockAsync(statePath, async () =>
            {
                await FileIoCoordinator.RetryOnSharingViolationAsync(async () =>
                {
                    await WriteFileCoreAsync(statePath, delimiter, stateHeaders!, updatedRows, ct);
                }, MaxAttempts, InitialDelay, ct);
            }, ct);
        }

        // FILE 3 (Output): Sync from STATE while keeping layout stable
        public static async Task SyncOutputFromStateAsync(
            string outputPath,
            string statePath,
            string delimiter,
            CancellationToken ct)
        {
            EnsureDirectory(outputPath);

            var (outHeaders, outRows) = ReadSnapshotSafe(outputPath, delimiter);
            var (stateHeaders, stateRows) = ReadSnapshotSafe(statePath, delimiter);

            if (stateHeaders is null)
            {
                if (File.Exists(statePath))
                    await CopyRawAsync(statePath, outputPath, ct);
                return;
            }

            if (outHeaders is null || !ArraysEqual(outHeaders!, stateHeaders!))
            {
                await CopyRawAsync(statePath, outputPath, ct);
                return;
            }

            int lockedRowCount = outRows.Count;
            int lockedColCount = outHeaders!.Length;

            var updatedRows = new List<string[]>(lockedRowCount);
            for (int i = 0; i < lockedRowCount; i++)
            {
                var prev = i < outRows.Count ? outRows[i] : new string[lockedColCount];
                var src = i < stateRows.Count ? stateRows[i] : new string[lockedColCount];

                var outRow = new string[lockedColCount];
                for (int c = 0; c < lockedColCount; c++)
                {
                    var srcVal = c < src.Length ? src[c] : string.Empty;
                    var prevVal = c < prev.Length ? prev[c] : string.Empty;
                    outRow[c] = string.IsNullOrWhiteSpace(srcVal) ? prevVal : srcVal;
                }
                updatedRows.Add(outRow);
            }

            await FileIoCoordinator.WithFileLockAsync(outputPath, async () =>
            {
                await FileIoCoordinator.RetryOnSharingViolationAsync(async () =>
                {
                    await WriteFileCoreAsync(outputPath, delimiter, outHeaders!, updatedRows, ct);
                }, MaxAttempts, InitialDelay, ct);
            }, ct);
        }

        // Public helper to force raw copy
        public static async Task CopyRawAsync(string src, string dst, CancellationToken ct)
        {
            EnsureDirectory(dst);
            await FileIoCoordinator.WithFileLockAsync(dst, async () =>
            {
                await FileIoCoordinator.RetryOnSharingViolationAsync(async () =>
                {
                    await CopyFileCoreAsync(src, dst, ct);
                }, MaxAttempts, InitialDelay, ct);
            }, ct);
        }

        // Core IO
        private static async Task WriteFileCoreAsync(
            string path,
            string delimiter,
            string[] headers,
            List<string[]> rows,
            CancellationToken ct)
        {
            var tmp = path + ".tmp";

            // Write tmp
            await using (var fs = new FileStream(tmp, FileMode.Create, FileAccess.Write, FileShare.None))
            await using (var sw = new StreamWriter(fs, new UTF8Encoding(false)))
            {
                var headerLine = headers.Length == 0 ? "Index" : $"Index{delimiter}{string.Join(delimiter, headers)}";
                await sw.WriteLineAsync(headerLine).ConfigureAwait(false);

                for (int i = 0; i < rows.Count; i++)
                {
                    var safe = rows[i] ?? Array.Empty<string>();
                    var body = string.Join(delimiter, safe.Select(Escape));
                    var line = $"{i + 1}{delimiter}{body}{delimiter}";
                    await sw.WriteLineAsync(line).ConfigureAwait(false);
                }
            }

            // Replace target with tmp (atomic rename after tmp is closed)
            if (File.Exists(path))
                File.Delete(path); 
            File.Move(tmp, path); 
        }

        private static async Task CopyFileCoreAsync(string src, string dst, CancellationToken ct)
        {
            var tmp = dst + ".tmp";
            await using (var inFs = new FileStream(src, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
            await using (var outFs = new FileStream(tmp, FileMode.Create, FileAccess.Write, FileShare.None))
            {
                await inFs.CopyToAsync(outFs, ct).ConfigureAwait(false);
            }

            if (File.Exists(dst))
                File.Delete(dst);
            File.Move(tmp, dst);
        }

        private static (string[]? Headers, List<string[]> Rows) ReadSnapshotSafe(string path, string delimiter)
        {
            var rows = new List<string[]>();
            if (!File.Exists(path))
                return (null, rows);

            try
            {
                using var sr = FileIoCoordinator.CreateReaderWithShare(path);
                string? line = sr.ReadLine();
                string[]? headers = null;

                if (line != null)
                {
                    var parts = line.Split(delimiter);
                    if (parts.Length > 0 && string.Equals(parts[0], "Index", StringComparison.Ordinal))
                        headers = parts.Skip(1).ToArray();
                    else
                        headers = parts.ToArray(); // unexpected header -> treat as mismatch
                }

                while ((line = sr.ReadLine()) != null)
                {
                    if (string.IsNullOrWhiteSpace(line)) continue;
                    var parts = line.Split(delimiter);
                    if (parts.Length == 0) continue;

                    var cols = parts.Skip(1).ToList();
                    if (cols.Count > 0 && string.IsNullOrEmpty(cols[^1]))
                        cols.RemoveAt(cols.Count - 1);

                    rows.Add(cols.ToArray());
                }

                return (headers, rows);
            }
            catch
            {
                return (null, new List<string[]>());
            }
        }

        // Utility
        private static void EnsureDirectory(string path)
        {
            var dir = Path.GetDirectoryName(path);
            if (!string.IsNullOrEmpty(dir))
                Directory.CreateDirectory(dir);
        }

        private static string[] BuildMergedHeaderCells(IReadOnlyList<string>? headers, IReadOnlyList<string>? betweenDelims)
        {
            var baseHeaders = (headers ?? Array.Empty<string>()).Select(Escape).ToArray();
            var merged = MergeColumnsByBetweenDelimiters(baseHeaders, betweenDelims);
            return merged.ToArray();
        }

        private static List<string[]> BuildMergedRows(
            IReadOnlyList<string[]> rowsBaseColumns,
            IReadOnlyList<string>? betweenDelims,
            int minColCount)
        {
            var list = new List<string[]>(rowsBaseColumns.Count);
            foreach (var row in rowsBaseColumns)
            {
                var baseCells = (row ?? Array.Empty<string>()).Select(Escape).ToArray();
                var merged = MergeColumnsByBetweenDelimiters(baseCells, betweenDelims);
                if (merged.Count < minColCount)
                    merged.AddRange(Enumerable.Repeat(string.Empty, minColCount - merged.Count));
                list.Add(merged.ToArray());
            }
            return list;
        }

        private static List<string> MergeColumnsByBetweenDelimiters(string[] cols, IReadOnlyList<string>? betweenDelims)
        {
            var result = new List<string>();
            if (cols.Length == 0) return result;

            string current = cols[0] ?? string.Empty;

            for (int i = 0; i < cols.Length - 1; i++)
            {
                string next = cols[i + 1] ?? string.Empty;
                string glue = (betweenDelims != null && i < betweenDelims.Count) ? (betweenDelims[i] ?? string.Empty) : string.Empty;

                if (!string.IsNullOrEmpty(glue))
                {
                    current = string.IsNullOrEmpty(next) ? current : (string.IsNullOrEmpty(current) ? next : current + glue + next);
                }
                else
                {
                    result.Add(current);
                    current = next;
                }
            }

            result.Add(current);
            return result;
        }

        private static bool ArraysEqual(string[] a, string[] b)
        {
            if (a.Length != b.Length) return false;
            for (int i = 0; i < a.Length; i++)
            {
                var s1 = (a[i] ?? string.Empty).Trim();
                var s2 = (b[i] ?? string.Empty).Trim();
                if (!string.Equals(s1, s2, StringComparison.Ordinal)) return false;
            }
            return true;
        }

        private static string Escape(string s)
            => s == null ? string.Empty : s.Replace("\r", " ").Replace("\n", " ").Trim();
    }
}
