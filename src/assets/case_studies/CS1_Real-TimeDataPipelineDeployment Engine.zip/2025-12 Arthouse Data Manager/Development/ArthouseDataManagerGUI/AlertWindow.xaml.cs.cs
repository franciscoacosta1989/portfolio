﻿/* 
    Developer: Francisco Acosta
    Company: NBC Universal - The Arthouse
    File Purpose: Creates a custom alert window with dynamic title, message, icon, and OK/Cancel buttons, adapting style for Windows 10 or 11.
*/

using System;
using System.Runtime.InteropServices;
using System.Windows;
using System.Windows.Interop;

namespace ArthouseDataManagerGUI.Views
{
    public partial class AlertWindow : Window
    {
        public AlertWindow(string title, string message, bool showCancel = false, string? iconUri = null)
        {
            InitializeComponent();
            DataContext = new AlertVM
            {
                TitleText = title,
                MessageText = message,
                CancelVisible = showCancel ? Visibility.Visible : Visibility.Collapsed,
                IconSource = iconUri ?? "/Assets/warning.png"
            };
        }

        protected override void OnSourceInitialized(EventArgs e)
        {
            base.OnSourceInitialized(e);

            if (IsWindows11OrLater())
            {
                // Native title bar color
                TrySetCaptionColor(ColorRefFromHex("#1d3b80")); // Arthouse Blue
            }
            else
            {
                // Windows 10 fallback: hide system bar, show custom red header
                WindowStyle = WindowStyle.None;
                CustomHeader.Visibility = Visibility.Visible;
            }
        }


        // In AlertWindow.xaml.cs
        private void OnOkClick(object sender, RoutedEventArgs e)
        {
            DialogResult = true;  // Yes / OK
            Close();
        }

        private void OnCancelClick(object sender, RoutedEventArgs e)
        {
            DialogResult = false; // No / Cancel
            Close();
        }

        private static bool IsWindows11OrLater()
        {
            var v = Environment.OSVersion.Version;
            return (v.Major == 10 && v.Build >= 22000) || v.Major > 10;
        }

        private void TrySetCaptionColor(uint colorRef)
        {
            var hwnd = new WindowInteropHelper(this).Handle;
            const int DWMWA_CAPTION_COLOR = 35;
            const int DWMWA_BORDER_COLOR = 34;
            try
            {
                DwmSetWindowAttribute(hwnd, DWMWA_CAPTION_COLOR, ref colorRef, (uint)Marshal.SizeOf<uint>());
                DwmSetWindowAttribute(hwnd, DWMWA_BORDER_COLOR, ref colorRef, (uint)Marshal.SizeOf<uint>());
            }
            catch { /* ignore */ }
        }

        private static uint ColorRefFromHex(string hex)
        {
            if (hex.StartsWith("#")) hex = hex[1..];
            byte r = Convert.ToByte(hex.Substring(0, 2), 16);
            byte g = Convert.ToByte(hex.Substring(2, 2), 16);
            byte b = Convert.ToByte(hex.Substring(4, 2), 16);
            return (uint)(b << 16 | g << 8 | r);
        }

        [DllImport("dwmapi.dll", PreserveSig = true)]
        private static extern int DwmSetWindowAttribute(IntPtr hwnd, int dwAttribute, ref uint pvAttribute, uint cbAttribute);
    }

    public class AlertVM
    {
        public string TitleText { get; set; } = "Alert";
        public string MessageText { get; set; } = "";
        public Visibility CancelVisible { get; set; } = Visibility.Collapsed;
        public string IconSource { get; set; } = "/Assets/warning.png";

        public System.Windows.Input.ICommand OkCommand => new RelayCommand(_ => Close(true));
        public System.Windows.Input.ICommand CloseCommand => new RelayCommand(_ => Close(false));

        private static void Close(bool ok)
        {
            var w = Application.Current.Windows.OfType<AlertWindow>().FirstOrDefault();
            if (w != null) w.DialogResult = ok;
            w?.Close();
        }
    }

    public class RelayCommand : System.Windows.Input.ICommand
    {
        private readonly Action<object?> _act;
        public RelayCommand(Action<object?> act) => _act = act;
        public bool CanExecute(object? parameter) => true;
        public void Execute(object? parameter) => _act(parameter);
        public event EventHandler? CanExecuteChanged;
    }
}
