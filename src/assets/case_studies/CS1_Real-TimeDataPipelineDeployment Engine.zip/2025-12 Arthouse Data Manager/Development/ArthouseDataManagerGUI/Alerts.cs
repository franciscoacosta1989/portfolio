﻿/* 
    Developer: Francisco Acosta
    Company: NBC Universal - The Arthouse
    File Purpose: Shows a custom alert dialog window.
*/

using System.Windows;

namespace ArthouseDataManagerGUI.Helpers
{
    public static class Alerts
    {
        public static void Show(Window owner, string title, string message, bool showCancel = false, string? iconUri = null)
        {
            var dlg = new Views.AlertWindow(title, message, showCancel, iconUri)
            {
                Owner = owner,
                WindowStartupLocation = WindowStartupLocation.CenterOwner
            };
            dlg.ShowDialog();
        }
    }
}
