/* 
    Developer: Francisco Acosta
    Company: NBC Universal - The Arthouse
    File Purpose: Specifies where WPF should look for theme and generic resource dictionaries.
*/
using System.Windows;


[assembly: ThemeInfo(
    ResourceDictionaryLocation.None,            //where theme specific resource dictionaries are located
                                                //(used if a resource is not found in the page,
                                                // or application resource dictionaries)
    ResourceDictionaryLocation.SourceAssembly   //where the generic resource dictionary is located
                                                //(used if a resource is not found in the page,
                                                // app, or any theme specific resource dictionaries)
)]
