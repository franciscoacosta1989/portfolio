﻿/* 
    Developer: Francisco Acosta
    Company: NBC Universal - The Arthouse
    File Purpose: Loads, edits, and saves stream configuration for the GUI.
*/

using System.Collections.ObjectModel;
using System.IO;
using ADMConfiguration.Configuration;
using ADMConfiguration.Data;

namespace ArthouseDataManagerGUI
{
    public class GuiApplication
    {
        public ObservableCollection<DataStream> Streams { get; private set; } = new ObservableCollection<DataStream>();
        private StreamManager _config = new StreamManager();

        // No default path; remain null until user picks a file.
        public string? CurrentConfigPath { get; private set; } = null;

        public void SetCurrentConfigPath(string? path)
        {
            CurrentConfigPath = path;
        }

        /// Load config from the provided path. If path is null or empty, start empty (do nothing).
        /// Sets CurrentConfigPath when a real path is given.
        public async Task LoadConfigAsync(string? path = null)
        {
            // If no path provided, do not load anything — start empty.
            if (string.IsNullOrWhiteSpace(path))
            {
                CurrentConfigPath = null;
                Streams.Clear();
                _config = new StreamManager(); // reset internal config representation
                return;
            }

            // Load from file
            _config = await ConfigManager.LoadConfigAsync(path);
            CurrentConfigPath = path;

            Streams.Clear();
            foreach (var stream in _config.Streams)
            {
                int dataCount = stream.SelectedObjects.Count;

                // ---- Headers: pad/trim to dataCount ----
                while (stream.SelectedHeaders.Count < dataCount)
                    stream.SelectedHeaders.Add(string.Empty);
                while (stream.SelectedHeaders.Count > dataCount)
                    stream.SelectedHeaders.RemoveAt(stream.SelectedHeaders.Count - 1);

                // ---- Delimiters: pad/trim to dataCount ----
                if (stream.SelectedDelimiters.Count == 0 && dataCount > 0)
                    stream.SelectedDelimiters.Add(string.IsNullOrWhiteSpace(stream.Delimiter) ? "|" : stream.Delimiter);

                while (stream.SelectedDelimiters.Count < dataCount)
                    stream.SelectedDelimiters.Add(string.IsNullOrWhiteSpace(stream.Delimiter) ? "|" : stream.Delimiter);
                while (stream.SelectedDelimiters.Count > dataCount)
                    stream.SelectedDelimiters.RemoveAt(stream.SelectedDelimiters.Count - 1);

                Streams.Add(stream);
            }
        }

        /// Save to provided path. If null, tries CurrentConfigPath. If both are null, throws to force a "Save As".
        public async Task SaveConfigAsync(string? path = null)
        {
            _config.Streams.Clear();

            foreach (var stream in Streams)
            {
                int dataCount = stream.SelectedObjects.Count;

                // ---- Headers: pad/trim to dataCount ----
                while (stream.SelectedHeaders.Count < dataCount)
                    stream.SelectedHeaders.Add(string.Empty);
                while (stream.SelectedHeaders.Count > dataCount)
                    stream.SelectedHeaders.RemoveAt(stream.SelectedHeaders.Count - 1);

                // ---- Delimiters: pad/trim to dataCount ----
                if (stream.SelectedDelimiters.Count == 0 && dataCount > 0)
                    stream.SelectedDelimiters.Add(string.IsNullOrWhiteSpace(stream.Delimiter) ? "|" : stream.Delimiter);

                while (stream.SelectedDelimiters.Count < dataCount)
                    stream.SelectedDelimiters.Add(string.IsNullOrWhiteSpace(stream.Delimiter) ? "|" : stream.Delimiter);
                while (stream.SelectedDelimiters.Count > dataCount)
                    stream.SelectedDelimiters.RemoveAt(stream.SelectedDelimiters.Count - 1);

                _config.Streams.Add(stream);
            }

            var savePath = path ?? CurrentConfigPath;

            if (string.IsNullOrWhiteSpace(savePath))
                throw new InvalidOperationException("No save path configured. Use 'Save' to pick a location.");

            // Ensure directory exists before saving
            var dir = Path.GetDirectoryName(savePath);
            if (!string.IsNullOrWhiteSpace(dir) && !Directory.Exists(dir))
                Directory.CreateDirectory(dir);

            await ConfigManager.SaveConfigAsync(_config, savePath);
            CurrentConfigPath = savePath;
        }

        public void AddStream(DataStream stream) => Streams.Add(stream);
        public void RemoveStream(DataStream stream) => Streams.Remove(stream);
    }
}
