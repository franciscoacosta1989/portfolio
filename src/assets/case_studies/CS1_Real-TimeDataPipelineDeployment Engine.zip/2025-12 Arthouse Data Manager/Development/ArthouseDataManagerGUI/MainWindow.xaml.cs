﻿/* 
    Developer: Francisco Acosta
    Company: NBC Universal - The Arthouse
    File Purpose: Windows UI Functionality
*/

using System.Collections.Specialized; 
using System.ComponentModel;
using System.IO;
using System.Runtime.InteropServices; 
using System.ServiceProcess;          
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives; 
using System.Windows.Data;
using System.Windows.Interop;         
using System.Windows.Markup;          
using System.Windows.Media;
using ADMConfiguration.Configuration;
using ADMConfiguration.Data;
using ADMConfiguration.Service;
using ArthouseDataManagerGUI.Views;
using Microsoft.Win32;                

namespace ArthouseDataManagerGUI
{
    public class IndexBasedTemplateSelector : DataTemplateSelector
    {
        public int Index { get; set; }
        public DataTemplate? ComboTemplate { get; set; }
        public DataTemplate? EmptyTemplate { get; set; }

        public override DataTemplate SelectTemplate(object item, DependencyObject container)
        {
            if (item is DataStream s && s.SelectedObjects != null && s.SelectedObjects.Count > Index)
                return ComboTemplate!;
            return EmptyTemplate!;
        }
    }

    public partial class MainWindow : Window
    {
        
        private GuiApplication? _guiApp;

        private WindowsServiceController _serviceController;
        private readonly StreamChoicesProvider _choicesProvider = new();

        private Style? _textBoxValidationStyle;
        private Style? _editingTextBoxStyle;
        private Style? _columnHeaderStyle;

        public MainWindow()
        {
            InitializeComponent();

            _guiApp = new GuiApplication();
            _serviceController = new WindowsServiceController("ArthouseDataManager");

            this.DataContext = _guiApp;

            var lastPath = Properties.Settings.Default.LastConfigPath;
            if (!string.IsNullOrWhiteSpace(lastPath))
            {
                _guiApp.SetCurrentConfigPath(lastPath);
            }

            _guiApp.Streams.CollectionChanged += Streams_CollectionChanged;
            HookExistingStreams();

            // Ensure at least one data slot exists
            EnsureSelectedObjectsLengthGlobal(0);

            // Build initial
            AttachTemplateSelectorsForInitialColumn();

            this.Loaded += (_, __) =>
            {
                ResolveSharedStyles();
                StreamsGrid.AutoGeneratingColumn += StreamsGrid_AutoGeneratingColumn;
                ApplyValidationToKnownColumns();
            };
        }

        /// Resolve shared styles defined in Styles/Controls.DataGrid.xaml
        private void ResolveSharedStyles()
        {
            try { _textBoxValidationStyle = (Style)FindResource("TextBoxValidationStyle"); }
            catch { _textBoxValidationStyle = null; }

            try { _editingTextBoxStyle = (Style)FindResource("EditingTextBoxStyle"); }
            catch { _editingTextBoxStyle = null; }

            try { _columnHeaderStyle = (Style)FindResource("AdmColumnHeaderStyle"); }
            catch { _columnHeaderStyle = null; }
        }

        private DataTemplate CreateTextBlockTemplate(string bindingPath, double minWidth)
        {
            var t = new DataTemplate();

            var border = new FrameworkElementFactory(typeof(Border));
            // Stretch to fill the DataGridCell
            border.SetValue(FrameworkElement.HorizontalAlignmentProperty, HorizontalAlignment.Stretch);
            border.SetValue(FrameworkElement.VerticalAlignmentProperty, VerticalAlignment.Stretch);
            border.SetValue(Border.BackgroundProperty, Brushes.Transparent);
            // Spacing owned by the border
            if (TryFindResource("Thickness.ControlPadding") is Thickness pad)
                border.SetValue(Border.PaddingProperty, pad);

            var tb = new FrameworkElementFactory(typeof(TextBlock));
            tb.SetBinding(TextBlock.TextProperty, new Binding(bindingPath));
            tb.SetValue(FrameworkElement.MinWidthProperty, minWidth);

            // Let the TextBlock stretch horizontally to fill (so background area is consistent)
            tb.SetValue(FrameworkElement.HorizontalAlignmentProperty, HorizontalAlignment.Stretch);
            tb.SetValue(FrameworkElement.VerticalAlignmentProperty, VerticalAlignment.Center);
            tb.SetValue(Control.PaddingProperty, new Thickness(0));   // spacing owned by Border
            tb.SetValue(FrameworkElement.MarginProperty, new Thickness(0));
            tb.SetValue(TextBlock.BackgroundProperty, Brushes.Transparent);
            if (TryFindResource("Brush.TextPrimary") is Brush fg) tb.SetValue(TextBlock.ForegroundProperty, fg);

            border.AppendChild(tb);
            t.VisualTree = border;
            return t;
        }


        private DataTemplate CreateTextBoxEditTemplate(string bindingPath, double minWidth)
        {
            var t = new DataTemplate();

            // Border replicates the shared padding (Thickness.ControlPadding)
            var border = new FrameworkElementFactory(typeof(Border));
            border.SetValue(FrameworkElement.HorizontalAlignmentProperty, HorizontalAlignment.Stretch);
            border.SetValue(FrameworkElement.VerticalAlignmentProperty, VerticalAlignment.Stretch);

            var tbx = new FrameworkElementFactory(typeof(TextBox));
            var binding = new Binding(bindingPath)
            {
                Mode = BindingMode.TwoWay,
                UpdateSourceTrigger = UpdateSourceTrigger.PropertyChanged,
                ValidatesOnNotifyDataErrors = true
            };
            tbx.SetBinding(TextBox.TextProperty, binding);

            tbx.SetValue(FrameworkElement.MinWidthProperty, minWidth);
            tbx.SetValue(FrameworkElement.HorizontalAlignmentProperty, HorizontalAlignment.Stretch);
            tbx.SetValue(FrameworkElement.VerticalAlignmentProperty, VerticalAlignment.Center);

            if (_editingTextBoxStyle != null)
            {
                tbx.SetValue(FrameworkElement.StyleProperty, _editingTextBoxStyle);
            }
            else
            {
                var styleObj = TryFindResource("EditingTextBoxStyle");
                if (styleObj is Style s)
                    tbx.SetValue(FrameworkElement.StyleProperty, s);
            }

            border.AppendChild(tbx);
            t.VisualTree = border;
            return t;
        }



        private DataTemplate CreateComboBoxTemplate(int index, bool editing, double minWidth)
        {
            var t = new DataTemplate();

            var cb = new FrameworkElementFactory(typeof(ComboBox));

            var itemsBinding = new Binding("DataContext.AvailableChoices")
            {
                RelativeSource = new RelativeSource(RelativeSourceMode.FindAncestor, typeof(DataGridRow), 1)
            };
            cb.SetBinding(ItemsControl.ItemsSourceProperty, itemsBinding);
            cb.SetValue(ComboBox.DisplayMemberPathProperty, "DisplayShort");
            cb.SetValue(ComboBox.SelectedValuePathProperty, "Path");
            cb.SetBinding(Selector.SelectedValueProperty, new Binding($"SelectedObjects[{index}]")
            {
                Mode = BindingMode.TwoWay,
                UpdateSourceTrigger = UpdateSourceTrigger.PropertyChanged
            });

            var styleKey = editing ? "AdmComboBoxEditStyle" : "AdmComboBoxCellStyle";
            if (TryFindResource(styleKey) is Style comboStyle)
                cb.SetValue(FrameworkElement.StyleProperty, comboStyle);

            // Make the ComboBox fill the entire cell
            cb.SetValue(FrameworkElement.HorizontalAlignmentProperty, HorizontalAlignment.Stretch);
            cb.SetValue(FrameworkElement.VerticalAlignmentProperty, VerticalAlignment.Stretch);

            // No extra spacing
            cb.SetValue(Control.PaddingProperty, new Thickness(0));
            cb.SetValue(FrameworkElement.MarginProperty, new Thickness(0));
            cb.SetValue(FrameworkElement.MinWidthProperty, minWidth);

            t.VisualTree = cb;
            return t;
        }



        // ------------------ Dynamic column creation that uses the styles/templates above ------------------



        private DataGridTemplateColumn CreateDataColumn(int index, bool isStar)
        {
            var headerText = index == 0 ? "Data 1" : $"Data {index + 1}";

            string comboCellXaml = $@"
            <DataTemplate xmlns='http://schemas.microsoft.com/winfx/2006/xaml/presentation'
                          xmlns:local='clr-namespace:ArthouseDataManagerGUI'>
              <ComboBox
                ItemsSource='{{Binding DataContext.AvailableChoices, RelativeSource={{RelativeSource AncestorType=DataGridRow}}}}'
                DisplayMemberPath='DisplayShort'
                SelectedValuePath='Path'
                SelectedValue='{{Binding SelectedObjects[{index}], Mode=TwoWay, UpdateSourceTrigger=PropertyChanged}}'
                MinWidth='160'
                HorizontalAlignment='Stretch'
                Foreground='#1d3b80'
                Background='#2D2D2D'
                BorderBrush='#555555'
                IsEditable='False'/>
            </DataTemplate>";
            var comboTemplate = (DataTemplate)XamlReader.Parse(comboCellXaml);

            string comboEditXaml = $@"
            <DataTemplate xmlns='http://schemas.microsoft.com/winfx/2006/xaml/presentation'
                          xmlns:local='clr-namespace:ArthouseDataManagerGUI'>
              <ComboBox
                ItemsSource='{{Binding DataContext.AvailableChoices, RelativeSource={{RelativeSource AncestorType=DataGridRow}}}}'
                DisplayMemberPath='DisplayShort'
                SelectedValuePath='Path'
                SelectedValue='{{Binding SelectedObjects[{index}], Mode=TwoWay, UpdateSourceTrigger=PropertyChanged}}'
                MinWidth='160'
                HorizontalAlignment='Stretch'
                Foreground='#1d3b80'
                Background='#FFFFFF'
                BorderBrush='#555555'
                IsEditable='False'/>
            </DataTemplate>";
            var comboEditingTemplate = (DataTemplate)XamlReader.Parse(comboEditXaml);

            var emptyTemplate = (DataTemplate)XamlReader.Parse(@"
            <DataTemplate xmlns='http://schemas.microsoft.com/winfx/2006/xaml/presentation'>
              <Border HorizontalAlignment='Stretch'
                      VerticalAlignment='Stretch'
                      Background='{DynamicResource Brush.CellEmpty}'
                      Padding='0'
                      Margin='0'/>
            </DataTemplate>");

                        var cellSelector = new IndexBasedTemplateSelector
            {
                Index = index,
                ComboTemplate = comboTemplate,
                EmptyTemplate = emptyTemplate
            };
            var editSelector = new IndexBasedTemplateSelector
            {
                Index = index,
                ComboTemplate = comboEditingTemplate,
                EmptyTemplate = emptyTemplate
            };

            var col = new DataGridTemplateColumn
            {
                Header = headerText,
                MinWidth = 160,
                Width = isStar ? new DataGridLength(1, DataGridLengthUnitType.Star)
                               : new DataGridLength(160),
                CellTemplateSelector = cellSelector,
                CellEditingTemplateSelector = editSelector
            };

            if (Resources["NoPaddingCell"] is Style cellStyle)
                col.CellStyle = cellStyle;

            var headerStyle = new Style(typeof(DataGridColumnHeader));
            headerStyle.Setters.Add(new Setter(Control.PaddingProperty, new Thickness(0)));
            headerStyle.Setters.Add(new Setter(Control.HorizontalContentAlignmentProperty, HorizontalAlignment.Stretch));
            headerStyle.Setters.Add(new Setter(Control.VerticalContentAlignmentProperty, VerticalAlignment.Stretch));
            headerStyle.Setters.Add(new Setter(Control.MarginProperty, new Thickness(0)));
            col.HeaderStyle = headerStyle;

            return col;
        }



        private DataGridTemplateColumn CreateDelimiterColumn(int index)
        {
            var headerText = index == 0 ? "Delimiter 1" : $"Delimiter {index + 1}";

            string cellXaml = $@"
            <DataTemplate xmlns='http://schemas.microsoft.com/winfx/2006/xaml/presentation'
                          xmlns:local='clr-namespace:ArthouseDataManagerGUI'>
              <TextBox
                Text='{{Binding SelectedDelimiters[{index}], Mode=TwoWay, UpdateSourceTrigger=PropertyChanged}}'
                MinWidth='100'
                HorizontalAlignment='Stretch'
                Foreground='White'
                Background='Transparent'
                BorderBrush='#555555'
                Padding='4'
                Style='{{DynamicResource TextBoxValidationStyle}}'/>
            </DataTemplate>";
            var cellTemplate = (DataTemplate)XamlReader.Parse(cellXaml);

            string editXaml = $@"
            <DataTemplate xmlns='http://schemas.microsoft.com/winfx/2006/xaml/presentation'
                          xmlns:local='clr-namespace:ArthouseDataManagerGUI'>
              <TextBox
                Text='{{Binding SelectedDelimiters[{index}], Mode=TwoWay, UpdateSourceTrigger=PropertyChanged}}'
                MinWidth='100'
                HorizontalAlignment='Stretch'
                Style='{{StaticResource EditingTextBoxStyle}}'/>
            </DataTemplate>";
            var editTemplate = (DataTemplate)XamlReader.Parse(editXaml);


            var emptyTemplate = (DataTemplate)XamlReader.Parse(@"
            <DataTemplate xmlns='http://schemas.microsoft.com/winfx/2006/xaml/presentation'>
              <Border HorizontalAlignment='Stretch'
                      VerticalAlignment='Stretch'
                      Background='{DynamicResource Brush.CellEmpty}'
                      Padding='0'
                      Margin='0'/>
            </DataTemplate>");


            var cellSelector = new IndexBasedTemplateSelector
            {
                Index = index,
                ComboTemplate = cellTemplate,
                EmptyTemplate = emptyTemplate
            };
            var editSelector = new IndexBasedTemplateSelector
            {
                Index = index,
                ComboTemplate = editTemplate,
                EmptyTemplate = emptyTemplate
            };

            var col = new DataGridTemplateColumn
            {
                Header = headerText,
                MinWidth = 100,
                Width = new DataGridLength(100),
                CellTemplateSelector = cellSelector,
                CellEditingTemplateSelector = editSelector
            };

            if (Resources["NoPaddingCell"] is Style cellStyle)
                col.CellStyle = cellStyle;

            var headerStyle = new Style(typeof(DataGridColumnHeader));
            headerStyle.Setters.Add(new Setter(Control.PaddingProperty, new Thickness(0)));
            headerStyle.Setters.Add(new Setter(Control.HorizontalContentAlignmentProperty, HorizontalAlignment.Stretch));
            headerStyle.Setters.Add(new Setter(Control.VerticalContentAlignmentProperty, VerticalAlignment.Stretch));
            headerStyle.Setters.Add(new Setter(Control.MarginProperty, new Thickness(0)));
            col.HeaderStyle = headerStyle;

            return col;
        }



        private DataGridTemplateColumn CreateHeaderColumn(int index)
        {
            var headerText = index == 0 ? "Header 1" : $"Header {index + 1}";

            string cellXaml = $@"
            <DataTemplate xmlns='http://schemas.microsoft.com/winfx/2006/xaml/presentation'
                          xmlns:local='clr-namespace:ArthouseDataManagerGUI'>
              <TextBox
                Text='{{Binding SelectedHeaders[{index}], Mode=TwoWay, UpdateSourceTrigger=PropertyChanged}}'
                MinWidth='160'
                HorizontalAlignment='Stretch'
                Foreground='White'
                Background='Transparent'
                BorderBrush='#555555'
                Padding='4'
                Style='{{DynamicResource TextBoxValidationStyle}}'/>
            </DataTemplate>";
            var cellTemplate = (DataTemplate)XamlReader.Parse(cellXaml);

            string editXaml = $@"
            <DataTemplate xmlns='http://schemas.microsoft.com/winfx/2006/xaml/presentation'
                          xmlns:local='clr-namespace:ArthouseDataManagerGUI'>
              <TextBox
                Text='{{Binding SelectedHeaders[{index}], Mode=TwoWay, UpdateSourceTrigger=PropertyChanged}}'
                MinWidth='160'
                HorizontalAlignment='Stretch'
                Style='{{StaticResource EditingTextBoxStyle}}'/>
            </DataTemplate>";
            var editTemplate = (DataTemplate)XamlReader.Parse(editXaml);

            var emptyTemplate = (DataTemplate)XamlReader.Parse(@"
            <DataTemplate xmlns='http://schemas.microsoft.com/winfx/2006/xaml/presentation'>
              <Border HorizontalAlignment='Stretch'
                      VerticalAlignment='Stretch'
                      Background='{DynamicResource Brush.CellEmpty}'
                      Padding='0'
                      Margin='0'/>
            </DataTemplate>");

            var cellSelector = new IndexBasedTemplateSelector
            {
                Index = index,
                ComboTemplate = cellTemplate,
                EmptyTemplate = emptyTemplate
            };
            var editSelector = new IndexBasedTemplateSelector
            {
                Index = index,
                ComboTemplate = editTemplate,
                EmptyTemplate = emptyTemplate
            };

            var col = new DataGridTemplateColumn
            {
                Header = headerText,
                MinWidth = 160,
                Width = new DataGridLength(160),
                CellTemplateSelector = cellSelector,
                CellEditingTemplateSelector = editSelector
            };

            if (Resources["NoPaddingCell"] is Style cellStyle)
                col.CellStyle = cellStyle;

            var headerStyle = new Style(typeof(DataGridColumnHeader));
            headerStyle.Setters.Add(new Setter(Control.PaddingProperty, new Thickness(0)));
            headerStyle.Setters.Add(new Setter(Control.HorizontalContentAlignmentProperty, HorizontalAlignment.Stretch));
            headerStyle.Setters.Add(new Setter(Control.VerticalContentAlignmentProperty, VerticalAlignment.Stretch));
            headerStyle.Setters.Add(new Setter(Control.MarginProperty, new Thickness(0)));
            col.HeaderStyle = headerStyle;

            return col;
        }


        private void ApplyHeaderStyle(DataGridTemplateColumn col)
        {
            if (_columnHeaderStyle != null)
            {
                col.HeaderStyle = _columnHeaderStyle;
            }
            else
            {
                var headerStyle = new Style(typeof(DataGridColumnHeader));
                headerStyle.Setters.Add(new Setter(Control.PaddingProperty, new Thickness(0)));
                headerStyle.Setters.Add(new Setter(Control.HorizontalContentAlignmentProperty, HorizontalAlignment.Stretch));
                headerStyle.Setters.Add(new Setter(Control.VerticalContentAlignmentProperty, VerticalAlignment.Stretch));
                headerStyle.Setters.Add(new Setter(Control.MarginProperty, new Thickness(0)));
                col.HeaderStyle = headerStyle;
            }
        }


        private void AttachTemplateSelectorsForInitialColumn()
        {
            if (_guiApp == null || StreamsGrid == null) return;

            // Ensure index 0 exists on all rows
            EnsureSelectedObjectsLengthGlobal(0);

            // If the first triple already exists, do nothing
            bool hasHeader1 = GetHeaderColumnForDataIndex(0) != null;
            bool hasDelim1 = GetDelimiterColumnForDataIndex(0) != null;
            bool hasData1 = GetDataColumnDisplayIndex(0) >= 0;
            if (hasHeader1 && hasDelim1 && hasData1)
                return;

            var headerCol = CreateHeaderColumn(0);
            var delimCol = CreateDelimiterColumn(0);
            var dataCol = CreateDataColumn(0, isStar: true);

            int actionsIndex = GetActionsColumnIndex();
            if (actionsIndex >= 0)
            {
                StreamsGrid.Columns.Insert(actionsIndex, headerCol);
                StreamsGrid.Columns.Insert(actionsIndex + 1, delimCol);
                StreamsGrid.Columns.Insert(actionsIndex + 2, dataCol);
            }
            else
            {
                StreamsGrid.Columns.Add(headerCol);
                StreamsGrid.Columns.Add(delimCol);
                StreamsGrid.Columns.Add(dataCol);
            }

            NormalizeDataColumnWidths();
            StreamsGrid.Items.Refresh();
            StreamsGrid.UpdateLayout();
        }


        private void LinkServiceToConfig_Click(object sender, RoutedEventArgs e)
        {
            // 1) Pick which config file to link to
            var dlg = new OpenFileDialog
            {
                Title = "Select Arthouse Data Manager config file",
                Filter = "JSON files (*.json)|*.json",
                InitialDirectory = @"C:\ArthouseDataManager\Config"
            };
            if (dlg.ShowDialog() != true) return;

            var selectedConfigPath = dlg.FileName;

            // 2) Write pointer
            var pointer = new ActiveConfigPointer { ConfigPath = selectedConfigPath };
            var json = System.Text.Json.JsonSerializer.Serialize(
                pointer,
                new System.Text.Json.JsonSerializerOptions { WriteIndented = true });

            var pointerPath = ActiveConfigPointer.DefaultPointerPath;
            Directory.CreateDirectory(Path.GetDirectoryName(pointerPath)!);
            File.WriteAllText(pointerPath, json);

            // 3) Prompt user or auto-restart
            var dlg2 = new AlertWindow(
                "Link Config",
                $"Linked service to:\n{selectedConfigPath}\n\nRestart the service now to apply?",
                showCancel: true // shows the "Cancel" button (acts as No)
            )
            {
                Owner = this,
                WindowStartupLocation = WindowStartupLocation.CenterOwner
            };

            var res = dlg2.ShowDialog(); // <-- use dlg2 here

            if (res == true) // OK = Yes
            {
                TryRestartService("ArthouseDataManager");
            }
        }


        private void TryRestartService(string serviceName)
        {
            try
            {
                using var sc = new ServiceController(serviceName);
                if (sc.Status != ServiceControllerStatus.Stopped)
                {
                    sc.Stop();
                    sc.WaitForStatus(ServiceControllerStatus.Stopped, TimeSpan.FromSeconds(20));
                }
                sc.Start();
                sc.WaitForStatus(ServiceControllerStatus.Running, TimeSpan.FromSeconds(20));
                Helpers.Alerts.Show(this, "Service Control", "Service restarted.");
            }
            catch (Exception)
            {
                Helpers.Alerts.Show(this, "Service Control", "Failed to restart service");
            }
        }


        private void StreamsGrid_AutoGeneratingColumn(object? sender, DataGridAutoGeneratingColumnEventArgs e)
        {
            if (e.Column is DataGridTextColumn textCol)
            {
                Binding newBinding;

                switch (e.PropertyName)
                {
                    case nameof(DataStream.Name):
                        newBinding = new Binding(nameof(DataStream.Name))
                        {
                            UpdateSourceTrigger = UpdateSourceTrigger.PropertyChanged,
                            NotifyOnValidationError = true
                        };
                        newBinding.ValidationRules.Add(new NotEmptyRule { FieldDisplayName = "Stream Name" });
                        textCol.Binding = newBinding;
                        if (_editingTextBoxStyle != null) textCol.EditingElementStyle = _editingTextBoxStyle;
                        break;

                    case nameof(DataStream.JsonUrl):
                        newBinding = new Binding(nameof(DataStream.JsonUrl))
                        {
                            UpdateSourceTrigger = UpdateSourceTrigger.PropertyChanged,
                            NotifyOnValidationError = true
                        };
                        newBinding.ValidationRules.Add(new NotEmptyRule { FieldDisplayName = "JSON URL" });
                        textCol.Binding = newBinding;
                        if (_editingTextBoxStyle != null) textCol.EditingElementStyle = _editingTextBoxStyle;
                        break;

                    case nameof(DataStream.FileLocation):
                        newBinding = new Binding(nameof(DataStream.FileLocation))
                        {
                            UpdateSourceTrigger = UpdateSourceTrigger.LostFocus,
                            NotifyOnValidationError = true
                        };
                        newBinding.ValidationRules.Add(new NotEmptyRule { FieldDisplayName = "File Location" });
                        newBinding.ValidationRules.Add(new WritableFolderRule { FieldDisplayName = "File Location" });
                        textCol.Binding = newBinding;
                        if (_editingTextBoxStyle != null) textCol.EditingElementStyle = _editingTextBoxStyle;
                        break;

                    case nameof(DataStream.IntervalSeconds):
                        newBinding = new Binding(nameof(DataStream.IntervalSeconds))
                        {
                            UpdateSourceTrigger = UpdateSourceTrigger.PropertyChanged,
                            NotifyOnValidationError = true
                        };
                        newBinding.ValidationRules.Add(new IntRangeRule
                        {
                            Min = 1,
                            Max = 86400,
                            FieldDisplayName = "Time (IntervalSeconds)"
                        });
                        textCol.Binding = newBinding;
                        if (_editingTextBoxStyle != null) textCol.EditingElementStyle = _editingTextBoxStyle;
                        break;

                    default:
                        break;
                }
            }
        }

        private void ApplyValidationToKnownColumns()
        {
            foreach (var col in StreamsGrid.Columns.OfType<DataGridTextColumn>())
            {
                var path = (col.Binding as Binding)?.Path?.Path ?? string.Empty;
                var headerStr = col.Header as string ?? string.Empty;

                bool isName = path == nameof(DataStream.Name) || headerStr.Equals("Name", StringComparison.OrdinalIgnoreCase);
                bool isUrl = path == nameof(DataStream.JsonUrl) || headerStr.Equals("JSON URL", StringComparison.OrdinalIgnoreCase) || headerStr.Equals("JsonUrl", StringComparison.OrdinalIgnoreCase);
                bool isFile = path == nameof(DataStream.FileLocation) || headerStr.Equals("File Location", StringComparison.OrdinalIgnoreCase) || headerStr.Equals("FileLocation", StringComparison.OrdinalIgnoreCase);
                bool isTime = path == nameof(DataStream.IntervalSeconds) || headerStr.Equals("Time", StringComparison.OrdinalIgnoreCase) || headerStr.Equals("IntervalSeconds", StringComparison.OrdinalIgnoreCase);

                if (isName)
                {
                    var b = new Binding(nameof(DataStream.Name))
                    {
                        UpdateSourceTrigger = UpdateSourceTrigger.PropertyChanged,
                        NotifyOnValidationError = true
                    };
                    b.ValidationRules.Add(new NotEmptyRule { FieldDisplayName = "Stream Name" });
                    col.Binding = b;
                    if (_editingTextBoxStyle != null) col.EditingElementStyle = _editingTextBoxStyle;
                }
                else if (isUrl)
                {
                    var b = new Binding(nameof(DataStream.JsonUrl))
                    {
                        UpdateSourceTrigger = UpdateSourceTrigger.PropertyChanged,
                        NotifyOnValidationError = true
                    };
                    b.ValidationRules.Add(new NotEmptyRule { FieldDisplayName = "JSON URL" });
                    col.Binding = b;
                    if (_editingTextBoxStyle != null) col.EditingElementStyle = _editingTextBoxStyle;
                }
                else if (isFile)
                {
                    var b = new Binding(nameof(DataStream.FileLocation))
                    {
                        UpdateSourceTrigger = UpdateSourceTrigger.LostFocus,
                        NotifyOnValidationError = true
                    };
                    b.ValidationRules.Add(new NotEmptyRule { FieldDisplayName = "File Location" });
                    b.ValidationRules.Add(new WritableFolderRule { FieldDisplayName = "File Location" });
                    col.Binding = b;
                    if (_editingTextBoxStyle != null) col.EditingElementStyle = _editingTextBoxStyle;
                }
                else if (isTime)
                {
                    var b = new Binding(nameof(DataStream.IntervalSeconds))
                    {
                        UpdateSourceTrigger = UpdateSourceTrigger.PropertyChanged,
                        NotifyOnValidationError = true
                    };
                    b.ValidationRules.Add(new IntRangeRule
                    {
                        Min = 1,
                        Max = 86400,
                        FieldDisplayName = "Time (IntervalSeconds)"
                    });
                    col.Binding = b;
                    if (_editingTextBoxStyle != null) col.EditingElementStyle = _editingTextBoxStyle;
                }
            }
        }

        // ---- Title bar/border (Windows 11+) ----
        protected override void OnSourceInitialized(EventArgs e)
        {
            base.OnSourceInitialized(e);

            var colorRef = ColorRefFromHex("#11234c");
            TrySetCaptionColor(colorRef);
            TrySetBorderColor(colorRef);
        }

        private static void TrySetCaptionColor(uint colorRef)
        {
            if (!IsWindows11OrLater()) return;
            var hwnd = new WindowInteropHelper(Application.Current.MainWindow!).Handle;
            const int DWMWA_CAPTION_COLOR = 35;
            try
            {
                DwmSetWindowAttribute(hwnd, DWMWA_CAPTION_COLOR, ref colorRef, (uint)Marshal.SizeOf<uint>());
            }
            catch { /* ignore */ }
        }

        private static void TrySetBorderColor(uint colorRef)
        {
            if (!IsWindows11OrLater()) return;
            var hwnd = new WindowInteropHelper(Application.Current.MainWindow!).Handle;
            const int DWMWA_BORDER_COLOR = 34;
            try
            {
                DwmSetWindowAttribute(hwnd, DWMWA_BORDER_COLOR, ref colorRef, (uint)Marshal.SizeOf<uint>());
            }
            catch { /* ignore */ }
        }

        private static bool IsWindows11OrLater()
        {
            var v = Environment.OSVersion.Version;
            return (v.Major == 10 && v.Build >= 22000) || v.Major > 10;
        }

        private static uint ColorRefFromHex(string hex)
        {
            if (string.IsNullOrWhiteSpace(hex)) throw new ArgumentException(nameof(hex));
            if (hex.StartsWith("#")) hex = hex[1..];
            if (hex.Length != 6) throw new ArgumentException("Hex must be RRGGBB.");

            byte r = Convert.ToByte(hex.Substring(0, 2), 16);
            byte g = Convert.ToByte(hex.Substring(2, 2), 16);
            byte b = Convert.ToByte(hex.Substring(4, 2), 16);

            return (uint)(b << 16 | g << 8 | r);
        }

        [DllImport("dwmapi.dll", PreserveSig = true)]
        private static extern int DwmSetWindowAttribute(
            IntPtr hwnd,
            int dwAttribute,
            ref uint pvAttribute,
            uint cbAttribute);

        // ------------------ Data actions ------------------

        private void AddStream_Click(object sender, RoutedEventArgs e)
        {
            if (_guiApp == null) return;

            _guiApp.AddStream(new DataStream
            {
                Name = string.Empty,
                Format = string.Empty,
                IntervalSeconds = null,
                FileLocation = string.Empty,
                JsonUrl = string.Empty
            });

            EnsureSelectedObjectsLengthGlobal(0);
            EnsureGridDataColumnsFromConfig();
        }

        private async void LoadConfig_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var dlg = new OpenFileDialog
                {
                    Title = "Select configuration file",
                    Filter = "JSON files (*.json)|*.json|All files (*.*)|*.*",
                    CheckFileExists = true,
                    Multiselect = false,
                    InitialDirectory = ResolveInitialDirectory(_guiApp?.CurrentConfigPath ?? Properties.Settings.Default.LastConfigPath)
                                       ?? Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments)
                };

                var picked = dlg.ShowDialog();
                if (picked == true && !string.IsNullOrWhiteSpace(dlg.FileName))
                {
                    if (_guiApp != null)
                    {
                        await _guiApp.LoadConfigAsync(dlg.FileName);
                        await RefreshAllStreamsAsync();

                        Properties.Settings.Default.LastConfigPath = dlg.FileName;
                        Properties.Settings.Default.Save();

                        EnsureSelectedObjectsLengthGlobal(0);
                        EnsureGridDataColumnsFromConfig();
                    }
                }
            }
            catch (Exception ex)
            {
                Helpers.Alerts.Show(this, "Error", $"Failed to load configuration file: {ex.Message}");
            }
        }

        private static string? ResolveInitialDirectory(string? path)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(path)) return null;

                if (File.Exists(path))
                    return Path.GetDirectoryName(path);

                if (Directory.Exists(path))
                    return path;

                var dir = Path.GetDirectoryName(path);
                if (!string.IsNullOrEmpty(dir) && Directory.Exists(dir))
                    return dir;
            }
            catch { }
            return null;
        }

        private static List<string> ValidateStream(DataStream s)
        {
            var errors = new List<string>();

            string displayName = string.IsNullOrWhiteSpace(s.Name) ? "(unnamed)" : s.Name;

            if (string.IsNullOrWhiteSpace(s.Name))
                errors.Add("Stream Name is required.");

            if (string.IsNullOrWhiteSpace(s.FileLocation))
            {
                errors.Add("File Location is required.");
            }
            else
            {
                try
                {
                    Directory.CreateDirectory(s.FileLocation);
                    var testFile = Path.Combine(s.FileLocation, ".adm_write_test.tmp");
                    using (File.Create(testFile)) { }
                    File.Delete(testFile);
                }
                catch (UnauthorizedAccessException)
                {
                    errors.Add($"Stream '{displayName}': Cannot write to folder '{s.FileLocation}'. Please choose a directory you have write permissions to.");
                }
                catch (Exception ex)
                {
                    errors.Add($"Stream '{displayName}': File Location '{s.FileLocation}' is invalid or inaccessible. Details: {ex.Message}");
                }
            }

            if (string.IsNullOrWhiteSpace(s.JsonUrl))
                errors.Add("JSON URL is required.");

            if (!s.IntervalSeconds.HasValue)
            {
                errors.Add("Time is required.");
            }
            else if (s.IntervalSeconds.Value <= 0)
            {
                errors.Add("Time (IntervalSeconds) must be greater than 0 seconds.");
            }
            else if (s.IntervalSeconds.Value > 24 * 60 * 60)
            {
                errors.Add("Time (IntervalSeconds) is unusually large (> 86400).");
            }

            return errors;
        }

        private async void SaveConfig_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (_guiApp == null) return;

                StreamsGrid?.CommitEdit(DataGridEditingUnit.Cell, true);
                StreamsGrid?.CommitEdit(DataGridEditingUnit.Row, true);

                var allErrors = new List<string>();
                foreach (var s in _guiApp.Streams)
                {
                    var errs = ValidateStream(s);
                    if (errs.Count > 0) allErrors.AddRange(errs);
                }

                if (allErrors.Count > 0)
                {
                    Helpers.Alerts.Show(this, "Validation Errors", string.Join(Environment.NewLine, allErrors));
                    return;
                }

                string initialDir = ResolveInitialDirectory(_guiApp?.CurrentConfigPath ?? Properties.Settings.Default.LastConfigPath)
                                    ?? Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);

                string suggestedFileName = "config.json";
                var seedPath = _guiApp?.CurrentConfigPath ?? Properties.Settings.Default.LastConfigPath;
                if (!string.IsNullOrWhiteSpace(seedPath))
                {
                    var existingName = Path.GetFileName(seedPath);
                    if (!string.IsNullOrWhiteSpace(existingName))
                        suggestedFileName = existingName;
                }

                var sfd = new SaveFileDialog
                {
                    Title = "Save Configuration",
                    Filter = "JSON files (*.json)|*.json|All files (*.*)|*.*",
                    AddExtension = true,
                    DefaultExt = ".json",
                    OverwritePrompt = true,
                    InitialDirectory = initialDir,
                    FileName = suggestedFileName
                };

                var picked = sfd.ShowDialog();
                if (picked == true && !string.IsNullOrWhiteSpace(sfd.FileName))
                {
                    var dir = Path.GetDirectoryName(sfd.FileName);
                    if (!string.IsNullOrWhiteSpace(dir) && !Directory.Exists(dir))
                        Directory.CreateDirectory(dir);

                    await _guiApp!.SaveConfigAsync(sfd.FileName);

                    Properties.Settings.Default.LastConfigPath = sfd.FileName;
                    Properties.Settings.Default.Save();

                    Helpers.Alerts.Show(this, "Error", $"Configuration file saved.");
                }
            }
            catch (Exception)
            {
                Helpers.Alerts.Show(this, "Error", $"Failed to save configuration.");
            }
        }

        private async void StartService_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var status = _serviceController.GetStatus();
                if (status == ServiceControllerStatus.Running || status == ServiceControllerStatus.StartPending)
                {
                    Helpers.Alerts.Show(this, "Service Control", "Service is already starting or running.");
                    return;
                }

                await _serviceController.StartServiceAsync();
                Helpers.Alerts.Show(this, "Service Control", "Service started.");
            }
            catch (InvalidOperationException ioe)
            {
                Helpers.Alerts.Show(this, "Service Control", ioe.Message);
            }
            catch (Exception ex)
            {
                Helpers.Alerts.Show(this, "Error", $"Failed to start service: {ex.Message}");
            }
        }

        private async void StopService_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                var status = _serviceController.GetStatus();
                if (status == ServiceControllerStatus.Stopped || status == ServiceControllerStatus.StopPending)
                {
                    Helpers.Alerts.Show(this, "Service Control", "Service is already stopping or stopped.");
                    return;
                }

                await _serviceController.StopServiceAsync();
                Helpers.Alerts.Show(this, "Service Control", "Service stopped.");
            }
            catch (InvalidOperationException ioe)
            {
                Helpers.Alerts.Show(this, "Service Control", ioe.Message);
            }
            catch (Exception)
            {
                Helpers.Alerts.Show(this, "Service Control", "Failed to stop service.");
            }
        }

        private async void RestartService_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                await _serviceController.RestartServiceAsync();
                Helpers.Alerts.Show(this, "Service Control", "Service restarted.");
            }
            catch (InvalidOperationException ioe)
            {
                Helpers.Alerts.Show(this, "Service Control", ioe.Message);
            }
            catch (Exception ex)
            {
                Helpers.Alerts.Show(this, "Error", $"Failed to restart service: {ex.Message}");
            }
        }

        private void Browse_Click(object sender, RoutedEventArgs e)
        {
            var btn = sender as Button;
            if (btn?.DataContext is DataStream rowItem)
            {
                var dialog = new OpenFileDialog
                {
                    CheckFileExists = false,
                    FileName = "Select Folder",
                    ValidateNames = false
                };

                if (dialog.ShowDialog() == true)
                {
                    var dir = Path.GetDirectoryName(dialog.FileName);
                    rowItem.FileLocation = string.IsNullOrWhiteSpace(dir) ? string.Empty : dir;

                    var grid = FindVisualParent<DataGrid>(btn);
                    grid?.CommitEdit(DataGridEditingUnit.Cell, exitEditingMode: true);
                    grid?.CommitEdit(DataGridEditingUnit.Row, exitEditingMode: true);

                    if (grid != null)
                    {
                        grid.SelectedItem = rowItem;
                        grid.UpdateLayout();
                        var view = CollectionViewSource.GetDefaultView(grid.ItemsSource);
                        view?.Refresh();
                    }
                }
            }
        }

        private static T? FindVisualParent<T>(DependencyObject? child) where T : DependencyObject
        {
            while (child != null)
            {
                var parent = VisualTreeHelper.GetParent(child);
                if (parent is T target) return target;
                child = parent;
            }
            return null;
        }

        private void SaveRow_Click(object sender, RoutedEventArgs e)
        {
            if (StreamsGrid?.SelectedItem is DataStream selectedStream)
            {
                Helpers.Alerts.Show(this, "Info", $"Stream '{selectedStream.Name}' updated in memory. Click 'Save' to persist changes.");
            }
        }

        // ------------------ Data columns add/remove ------------------

        private void AddDataChoice_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (StreamsGrid == null) return;

                StreamsGrid.CommitEdit(DataGridEditingUnit.Cell, true);
                StreamsGrid.CommitEdit(DataGridEditingUnit.Row, true);

                if (sender is Button btn && btn.DataContext is DataStream s)
                {
                    int preEnsureCount = s.SelectedObjects?.Count ?? 0;

                    EnsureSelectedObjectsLengthForRow(s, preEnsureCount);
                    EnsureSelectedHeadersLengthForRow(s, preEnsureCount);
                    EnsureSelectedDelimitersLengthForRow(s, preEnsureCount);

                    int ensuredIndex = Math.Max(0, (s.SelectedObjects?.Count ?? 1) - 1);

                    if (s.AvailableChoices != null && s.AvailableChoices.Count > 0)
                    {
                        if (string.IsNullOrWhiteSpace(s.SelectedObjects![ensuredIndex]))
                        {
                            var firstLeaf = s.AvailableChoices.FirstOrDefault(c => c.Kind == ChoiceKind.Value)
                                            ?? s.AvailableChoices[0];
                            s.SelectedObjects[ensuredIndex] = firstLeaf.Path;
                        }
                    }
                    if (string.IsNullOrWhiteSpace(s.SelectedHeaders[ensuredIndex]))
                        s.SelectedHeaders[ensuredIndex] = string.Empty;

                    if (string.IsNullOrWhiteSpace(s.SelectedDelimiters[ensuredIndex]))
                        s.SelectedDelimiters[ensuredIndex] = string.IsNullOrWhiteSpace(s.Delimiter) ? "|" : s.Delimiter;

                    int maxDataNumberInGrid = GetMaxDataColumnNumber();
                    int requiredNumber = ensuredIndex + 1;

                    if (requiredNumber > maxDataNumberInGrid)
                    {
                        var prevStar = GetLastDataColumn(isStarOnly: true);
                        if (prevStar != null)
                            prevStar.Width = new DataGridLength(160);

                        var headerCol = CreateHeaderColumn(ensuredIndex);
                        var delimCol = CreateDelimiterColumn(ensuredIndex);
                        var dataCol = CreateDataColumn(ensuredIndex, isStar: true);

                        int actionsIndex = GetActionsColumnIndex();
                        if (actionsIndex >= 0)
                        {
                            StreamsGrid.Columns.Insert(actionsIndex, headerCol);
                            StreamsGrid.Columns.Insert(actionsIndex + 1, delimCol);
                            StreamsGrid.Columns.Insert(actionsIndex + 2, dataCol);
                        }
                        else
                        {
                            StreamsGrid.Columns.Add(headerCol);
                            StreamsGrid.Columns.Add(delimCol);
                            StreamsGrid.Columns.Add(dataCol);
                        }
                    }

                    StreamsGrid.Items.Refresh();
                    StreamsGrid.UpdateLayout();
                    var view = CollectionViewSource.GetDefaultView(StreamsGrid.ItemsSource);
                    view?.Refresh();
                    StreamsGrid.UpdateLayout();

                    int dataColumnIndex = GetDataColumnDisplayIndex(ensuredIndex);
                    if (dataColumnIndex >= 0)
                    {
                        StreamsGrid.ScrollIntoView(s, StreamsGrid.Columns[dataColumnIndex]);
                        var rowObj = StreamsGrid.ItemContainerGenerator.ContainerFromItem(s);
                        var row = rowObj as DataGridRow;
                        if (row != null)
                        {
                            var cell = GetCell(StreamsGrid, row, dataColumnIndex);
                            var combo = cell != null ? FindVisualChild<ComboBox>(cell) : null;
                            if (combo != null)
                            {
                                combo.Focus();
                                combo.IsDropDownOpen = true;
                            }
                        }
                    }

                    NormalizeDataColumnWidths();
                }
            }
            catch (Exception ex)
            {
                Helpers.Alerts.Show(this, "Error", $"Failed to add data: {ex.Message}");
            }
        }


        private void RemoveDataColumn_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (_guiApp == null || StreamsGrid == null) return;

                StreamsGrid.CommitEdit(DataGridEditingUnit.Cell, true);
                StreamsGrid.CommitEdit(DataGridEditingUnit.Row, true);

                if (sender is Button btn && btn.DataContext is ADMConfiguration.Data.DataStream s)
                {
                    int removedIndex = Math.Max(0, (s.SelectedObjects?.Count ?? 1) - 1);

                    bool otherRowsHaveIndex = _guiApp.Streams.Any(r =>
                        !ReferenceEquals(r, s) &&
                        r.SelectedObjects != null &&
                        r.SelectedObjects.Count > removedIndex);

                    if (!otherRowsHaveIndex)
                    {
                        if (CountDataColumns() <= 1)
                        {
                            RemoveRowDataAtIndex(s, removedIndex);
                            Helpers.Alerts.Show(this, "Info", "There must be at least one Data column. Removed the selection from this row only.");
                        }
                        else
                        {
                            foreach (var r in _guiApp.Streams)
                                RemoveRowDataAtIndex(r, removedIndex);

                            RebuildDataColumnsFromStreams();
                        }
                    }
                    else
                    {
                        RemoveRowDataAtIndex(s, removedIndex);
                        RebuildDataColumnsFromStreams();
                    }

                    StreamsGrid.Items.Refresh();
                    StreamsGrid.UpdateLayout();
                }
            }
            catch (Exception ex)
            {
                Helpers.Alerts.Show(this, "Error", $"Failed to remove data column: {ex.Message}");
            }
        }

        private static void RemoveRowDataAtIndex(DataStream s, int index)
        {
            if (s.SelectedObjects != null && s.SelectedObjects.Count > index)
                s.SelectedObjects.RemoveAt(index);

            if (s.SelectedHeaders != null && s.SelectedHeaders.Count > index)
                s.SelectedHeaders.RemoveAt(index);

            if (s.SelectedDelimiters != null && s.SelectedDelimiters.Count > index)
                s.SelectedDelimiters.RemoveAt(index);
        }

        private void RebuildDataColumnsFromStreams()
        {
            if (_guiApp?.Streams == null || StreamsGrid == null) return;

            // Remove existing Header/Delimiter/Data columns.
            var toRemove = StreamsGrid.Columns
                .Where(c => c.Header is string h &&
                            (h.StartsWith("Header", StringComparison.OrdinalIgnoreCase) ||
                             h.StartsWith("Delimiter", StringComparison.OrdinalIgnoreCase) ||
                             h.StartsWith("Data", StringComparison.OrdinalIgnoreCase)))
                .ToList();

            foreach (var c in toRemove)
                StreamsGrid.Columns.Remove(c);

            int maxDataCount = _guiApp.Streams
                .Select(s => s.SelectedObjects?.Count ?? 0)
                .DefaultIfEmpty(1)
                .Max();

            maxDataCount = Math.Max(1, maxDataCount);

            // Insert triple columns again (Header / Delimiter / Data) before Actions.
            for (int i = 0; i < maxDataCount; i++)
            {
                var headerCol = CreateHeaderColumn(i);
                var delimCol = CreateDelimiterColumn(i);
                var dataCol = CreateDataColumn(i, isStar: i == maxDataCount - 1);

                int actionsIndex = GetActionsColumnIndex();
                if (actionsIndex >= 0)
                {
                    StreamsGrid.Columns.Insert(actionsIndex, headerCol);
                    StreamsGrid.Columns.Insert(actionsIndex + 1, delimCol);
                    StreamsGrid.Columns.Insert(actionsIndex + 2, dataCol);
                }
                else
                {
                    StreamsGrid.Columns.Add(headerCol);
                    StreamsGrid.Columns.Add(delimCol);
                    StreamsGrid.Columns.Add(dataCol);
                }
            }

            NormalizeDataColumnWidths();

            StreamsGrid.Items.Refresh();
            StreamsGrid.UpdateLayout();
        }

        private void EnsureGridDataColumnsFromConfig()
        {
            if (_guiApp?.Streams == null || StreamsGrid == null) return;

            int maxDataCount = _guiApp.Streams
                .Select(s => s.SelectedObjects?.Count ?? 0)
                .DefaultIfEmpty(1)
                .Max();

            maxDataCount = Math.Max(1, maxDataCount);

            var dataCols = StreamsGrid.Columns
                .Where(c => c.Header is string h && h.StartsWith("Data", StringComparison.OrdinalIgnoreCase))
                .ToList();

            int currentCount = dataCols.Count;

            for (int index = currentCount; index < maxDataCount; index++)
            {
                var prevStar = GetLastDataColumn(isStarOnly: true);
                if (prevStar != null)
                    prevStar.Width = new DataGridLength(160);

                var headerCol = CreateHeaderColumn(index);
                var delimCol = CreateDelimiterColumn(index);
                var dataCol = CreateDataColumn(index, isStar: true);

                int actionsIndex = GetActionsColumnIndex();
                if (actionsIndex >= 0)
                {
                    StreamsGrid.Columns.Insert(actionsIndex, headerCol);
                    StreamsGrid.Columns.Insert(actionsIndex + 1, delimCol);
                    StreamsGrid.Columns.Insert(actionsIndex + 2, dataCol);
                }
                else
                {
                    StreamsGrid.Columns.Add(headerCol);
                    StreamsGrid.Columns.Add(delimCol);
                    StreamsGrid.Columns.Add(dataCol);
                }
            }

            NormalizeDataColumnWidths();

            StreamsGrid.Items.Refresh();
            StreamsGrid.UpdateLayout();
        }

        private int CountDataColumns()
        {
            return StreamsGrid.Columns.Count(c =>
                c.Header is string h &&
                h.StartsWith("Data", StringComparison.OrdinalIgnoreCase));
        }

        private int GetMaxDataColumnNumber()
        {
            int max = 0;
            foreach (var col in StreamsGrid.Columns)
            {
                if (col.Header is string h && h.StartsWith("Data", StringComparison.OrdinalIgnoreCase))
                {
                    var parts = h.Split(' ');
                    if (parts.Length == 2 && int.TryParse(parts[1], out int n))
                        max = Math.Max(max, n);
                    else
                        max = Math.Max(max, 1);
                }
            }
            return max;
        }

        private int GetDataColumnDisplayIndex(int dataIndex)
        {
            string targetHeader = dataIndex == 0 ? "Data 1" : $"Data {dataIndex + 1}";
            for (int i = 0; i < StreamsGrid.Columns.Count; i++)
            {
                if (Equals(StreamsGrid.Columns[i].Header, targetHeader))
                    return i;
            }
            return -1;
        }

        private int GetActionsColumnIndex()
        {
            for (int i = 0; i < StreamsGrid.Columns.Count; i++)
            {
                if (Equals(StreamsGrid.Columns[i].Header, "Actions"))
                    return i;
            }
            return -1;
        }

        private DataGridColumn? GetLastDataColumn(bool isStarOnly)
        {
            var dataCols = StreamsGrid.Columns
                .Where(c => c.Header is string h && h.StartsWith("Data", StringComparison.OrdinalIgnoreCase))
                .OfType<DataGridColumn>()
                .ToList();

            if (isStarOnly)
                return dataCols.LastOrDefault(c => c.Width.IsStar);
            return dataCols.LastOrDefault();
        }

        private void EnsureSelectedObjectsLengthForRow(DataStream s, int index)
        {
            if (s.SelectedObjects == null) return;
            while (s.SelectedObjects.Count <= index)
                s.SelectedObjects.Add(string.Empty);
        }

        private void EnsureSelectedHeadersLengthForRow(DataStream s, int index)
        {
            if (s.SelectedHeaders == null) return;
            while (s.SelectedHeaders.Count <= index)
                s.SelectedHeaders.Add(string.Empty);
        }

        private void EnsureSelectedDelimitersLengthForRow(DataStream s, int index)
        {
            if (s.SelectedDelimiters == null) return;
            while (s.SelectedDelimiters.Count <= index)
                s.SelectedDelimiters.Add(string.IsNullOrWhiteSpace(s.Delimiter) ? "|" : s.Delimiter);
        }

        private void NormalizeDataColumnWidths()
        {
            var dataColumns = StreamsGrid.Columns
                .Where(c => c.Header is string h && h.StartsWith("Data", StringComparison.OrdinalIgnoreCase))
                .OfType<DataGridColumn>()
                .ToList();

            for (int i = 0; i < dataColumns.Count; i++)
            {
                if (i == dataColumns.Count - 1)
                    dataColumns[i].Width = new DataGridLength(1, DataGridLengthUnitType.Star);
                else
                    dataColumns[i].Width = new DataGridLength(160);
            }
        }

        private static DataGridCell? GetCell(DataGrid grid, DataGridRow row, int columnIndex)
        {
            if (grid == null || row == null) return null;

            var presenter = FindVisualChild<DataGridCellsPresenter>(row);
            if (presenter == null)
            {
                grid.ScrollIntoView(row, grid.Columns[columnIndex]);
                presenter = FindVisualChild<DataGridCellsPresenter>(row);
                if (presenter == null) return null;
            }

            var cellObj = presenter.ItemContainerGenerator.ContainerFromIndex(columnIndex);
            var cell = cellObj as DataGridCell;
            if (cell == null)
            {
                grid.ScrollIntoView(row, grid.Columns[columnIndex]);
                cellObj = presenter.ItemContainerGenerator.ContainerFromIndex(columnIndex);
                cell = cellObj as DataGridCell;
            }
            return cell;
        }

        private static T? FindVisualChild<T>(DependencyObject parent) where T : DependencyObject
        {
            if (parent == null) return null;
            for (int i = 0; i < VisualTreeHelper.GetChildrenCount(parent); i++)
            {
                var child = VisualTreeHelper.GetChild(parent, i);
                if (child is T match) return match;
                var nested = FindVisualChild<T>(child);
                if (nested != null) return nested;
            }
            return null;
        }

        private void Streams_CollectionChanged(object? sender, NotifyCollectionChangedEventArgs e)
        {
            if (e.NewItems != null)
            {
                foreach (var item in e.NewItems.OfType<DataStream>())
                    item.PropertyChanged += Stream_PropertyChanged;
            }
            if (e.OldItems != null)
            {
                foreach (var item in e.OldItems.OfType<DataStream>())
                    item.PropertyChanged -= Stream_PropertyChanged;
            }
        }

        private void HookExistingStreams()
        {
            if (_guiApp == null) return;
            foreach (var s in _guiApp.Streams)
                s.PropertyChanged += Stream_PropertyChanged;
        }

        private async void Stream_PropertyChanged(object? sender, PropertyChangedEventArgs e)
        {
            if (sender is DataStream s && e.PropertyName == nameof(DataStream.JsonUrl))
            {
                if (string.IsNullOrWhiteSpace(s.JsonUrl))
                {
                    Dispatcher.Invoke(() =>
                    {
                        s.AvailableChoices.Clear();
                        s.AvailableChoices.Add(new ChoiceItem
                        {
                            Path = "",
                            Display = "(no JSON URL)",
                            DisplayShort = "(no JSON URL)",
                            Type = "unknown",
                            Kind = ChoiceKind.Value
                        });

                        if (s.SelectedObjects.Count == 0) s.SelectedObjects.Add(string.Empty);
                        if (s.SelectedHeaders.Count == 0) s.SelectedHeaders.Add(string.Empty);
                        if (s.SelectedDelimiters.Count == 0) s.SelectedDelimiters.Add(string.IsNullOrWhiteSpace(s.Delimiter) ? "|" : s.Delimiter);
                    });
                    return;
                }

                await RefreshStreamAsync(s);
            }
        }

        private async Task LoadAndRefreshAsync(string? path)
        {
            if (_guiApp == null) return;
            await _guiApp.LoadConfigAsync(path);
            await RefreshAllStreamsAsync();

            EnsureSelectedObjectsLengthGlobal(0);
            EnsureGridDataColumnsFromConfig();
        }

        private async Task RefreshAllStreamsAsync()
        {
            if (_guiApp == null) return;
            foreach (var s in _guiApp.Streams)
                await RefreshStreamAsync(s);
        }

        private async Task RefreshStreamAsync(DataStream s)
        {
            if (string.IsNullOrWhiteSpace(s.JsonUrl))
            {
                Dispatcher.Invoke(() =>
                {
                    s.AvailableChoices.Clear();
                    s.AvailableChoices.Add(new ChoiceItem
                    {
                        Path = "",
                        Display = "(no JSON URL)",
                        DisplayShort = "(no JSON URL)",
                        Type = "unknown",
                        Kind = ChoiceKind.Value
                    });

                    if (s.SelectedObjects.Count == 0) s.SelectedObjects.Add(string.Empty);
                    if (s.SelectedHeaders.Count == 0) s.SelectedHeaders.Add(string.Empty);
                    if (s.SelectedDelimiters.Count == 0) s.SelectedDelimiters.Add(string.IsNullOrWhiteSpace(s.Delimiter) ? "|" : s.Delimiter);
                });
                return;
            }

            Dispatcher.Invoke(() =>
            {
                s.AvailableChoices.Clear();
                s.AvailableChoices.Add(new ChoiceItem
                {
                    Path = "",
                    Display = "(loading…)",
                    DisplayShort = "(loading…)",
                    Type = "unknown",
                    Kind = ChoiceKind.Value
                });
            });

            var allChoices = await _choicesProvider.GetAllPathsAsync(s.JsonUrl, maxDepth: int.MaxValue);
            var leafChoices = allChoices.Where(c => c.Kind == ChoiceKind.Value).ToList();

            Dispatcher.Invoke(() =>
            {
                s.AvailableChoices.Clear();
                foreach (var c in leafChoices)
                    s.AvailableChoices.Add(c);

                if (s.SelectedObjects.Count == 0)
                    s.SelectedObjects.Add(s.AvailableChoices.Count > 0 ? s.AvailableChoices[0].Path : string.Empty);

                if (s.SelectedHeaders.Count == 0)
                    s.SelectedHeaders.Add(string.Empty);

                if (s.SelectedDelimiters.Count == 0)
                    s.SelectedDelimiters.Add(string.IsNullOrWhiteSpace(s.Delimiter) ? "|" : s.Delimiter);
            });
        }

        private void RemoveRow_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (_guiApp == null || StreamsGrid == null) return;

                StreamsGrid.CommitEdit(DataGridEditingUnit.Cell, true);
                StreamsGrid.CommitEdit(DataGridEditingUnit.Row, true);

                if (sender is Button btn && btn.DataContext is DataStream s)
                {
                    _guiApp.Streams.Remove(s);

                    if (_guiApp.Streams.Count > 0)
                    {
                        StreamsGrid.SelectedItem = _guiApp.Streams[0];
                        StreamsGrid.ScrollIntoView(StreamsGrid.SelectedItem);
                    }
                    StreamsGrid.UpdateLayout();
                }
            }
            catch (Exception ex)
            {
                Helpers.Alerts.Show(this, "Error", $"Failed to remove row: {ex.Message}");
            }
        }

        private DataGridColumn? GetHeaderColumnForDataIndex(int dataIndex)
        {
            string targetHeader = dataIndex == 0 ? "Header 1" : $"Header {dataIndex + 1}";
            return StreamsGrid?.Columns.FirstOrDefault(c => Equals(c.Header, targetHeader));
        }

        private DataGridColumn? GetDelimiterColumnForDataIndex(int dataIndex)
        {
            string targetHeader = dataIndex == 0 ? "Delimiter 1" : $"Delimiter {dataIndex + 1}";
            return StreamsGrid?.Columns.FirstOrDefault(c => Equals(c.Header, targetHeader));
        }

        private void EnsureSelectedObjectsLengthGlobal(int index)
        {
            if (_guiApp?.Streams == null) return;
            foreach (var s in _guiApp.Streams)
            {
                EnsureSelectedObjectsLengthForRow(s, index);
                EnsureSelectedHeadersLengthForRow(s, index);
                EnsureSelectedDelimitersLengthForRow(s, index);
            }
        }
    }
}
