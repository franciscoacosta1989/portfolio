﻿/* 
    Developer: Francisco Acosta
    Company: NBC Universal - The Arthouse
    File Purpose: Validates text, number range, and folder existence/writability.
*/

using System;
using System.Globalization;
using System.IO;
using System.Windows.Controls;

namespace ArthouseDataManagerGUI
{
    /// Validates a non-empty string (no null/whitespace).
    public class NotEmptyRule : ValidationRule
    {
        public string? FieldDisplayName { get; set; }

        public override ValidationResult Validate(object value, CultureInfo cultureInfo)
        {
            var s = value as string;
            if (string.IsNullOrWhiteSpace(s))
            {
                var name = string.IsNullOrWhiteSpace(FieldDisplayName) ? "Value" : FieldDisplayName;
                return new ValidationResult(false, $"{name} is required.");
            }
            return ValidationResult.ValidResult;
        }
    }

    /// Validates integer ranges with friendly errors.
    public class IntRangeRule : ValidationRule
    {
        public int Min { get; set; } = 1;
        public int Max { get; set; } = 86400;
        public string? FieldDisplayName { get; set; } = "Time (seconds)";

        public override ValidationResult Validate(object value, CultureInfo cultureInfo)
        {
            var s = value as string;
            if (string.IsNullOrWhiteSpace(s))
                return new ValidationResult(false, $"{FieldDisplayName} is required.");

            if (!int.TryParse(s, System.Globalization.NumberStyles.Integer, cultureInfo, out var i))
                return new ValidationResult(false, $"{FieldDisplayName} must be a whole number.");

            if (i < Min || i > Max)
                return new ValidationResult(false, $"{FieldDisplayName} must be between {Min} and {Max}.");

            return ValidationResult.ValidResult;
        }
    }

    /// Validates folder exists or can be created & is writable.
    public class WritableFolderRule : ValidationRule
    {
        public string? FieldDisplayName { get; set; } = "File Location";

        public override ValidationResult Validate(object value, CultureInfo cultureInfo)
        {
            var path = value as string;
            if (string.IsNullOrWhiteSpace(path))
                return new ValidationResult(false, $"{FieldDisplayName} is required.");

            try
            {
                Directory.CreateDirectory(path); // creates on purpose (legacy behavior)
                var testFile = Path.Combine(path, ".adm_write_test.tmp");
                using (File.Create(testFile)) { }
                File.Delete(testFile);
            }
            catch (UnauthorizedAccessException)
            {
                return new ValidationResult(false, $"{FieldDisplayName} '{path}' is not writable. Choose a folder you have write access to.");
            }
            catch (Exception ex)
            {
                return new ValidationResult(false, $"{FieldDisplayName} '{path}' is invalid or inaccessible. {ex.Message}");
            }

            return ValidationResult.ValidResult;
        }
    }

    /// Validates that the folder exists (does NOT create it).
    public class ExistingFolderRule : ValidationRule
    {
        public string? FieldDisplayName { get; set; } = "File Location";

        public override ValidationResult Validate(object value, CultureInfo cultureInfo)
        {
            var path = value as string;
            if (string.IsNullOrWhiteSpace(path))
                return new ValidationResult(false, $"{FieldDisplayName} is required.");

            if (!Directory.Exists(path))
                return new ValidationResult(false, $"{FieldDisplayName} '{path}' does not exist.");

            return ValidationResult.ValidResult;
        }
    }

    /// Validates that the folder exists and is writable, without creating it.
    public class ExistingWritableFolderRule : ValidationRule
    {
        public string? FieldDisplayName { get; set; } = "File Location";

        public override ValidationResult Validate(object value, CultureInfo cultureInfo)
        {
            var path = value as string;
            if (string.IsNullOrWhiteSpace(path))
                return new ValidationResult(false, $"{FieldDisplayName} is required.");

            if (!Directory.Exists(path))
                return new ValidationResult(false, $"{FieldDisplayName} '{path}' does not exist.");

            try
            {
                var testFile = Path.Combine(path, ".adm_write_test.tmp");
                using (File.Create(testFile)) { }
                File.Delete(testFile);
            }
            catch (UnauthorizedAccessException)
            {
                return new ValidationResult(false, $"{FieldDisplayName} '{path}' is not writable. Choose a folder you have write access to.");
            }
            catch (Exception ex)
            {
                return new ValidationResult(false, $"{FieldDisplayName} '{path}' is invalid or inaccessible. {ex.Message}");
            }

            return ValidationResult.ValidResult;
        }
    }
}
