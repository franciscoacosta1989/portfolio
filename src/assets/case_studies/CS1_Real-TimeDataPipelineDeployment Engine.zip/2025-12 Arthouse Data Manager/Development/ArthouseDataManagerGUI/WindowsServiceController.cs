﻿
/* 
    Developer: Francisco Acosta
    Company: NBC Universal - The Arthouse
    File Purpose: Start, stop and restart windows service via GUI
*/

using System.Diagnostics;
using System.ServiceProcess;

namespace ArthouseDataManagerGUI
{
    public class WindowsServiceController
    {
        private readonly string _serviceName;

        public WindowsServiceController(string serviceName)
        {
            _serviceName = serviceName ?? throw new ArgumentNullException(nameof(serviceName));
        }

        private ServiceController GetService()
        {
            var sc = new ServiceController(_serviceName);
            try
            {
                sc.Refresh();
                _ = sc.Status; // force resolution
                return sc;
            }
            catch (InvalidOperationException ex)
            {
                throw new InvalidOperationException(
                    $"Service '{_serviceName}' not found. Ensure it is installed with this exact name.", ex);
            }
        }

        // --------- Start / Stop / Restart ---------

        public Task StartServiceAsync() => Task.Run(() =>
        {
            using var sc = GetService();
            sc.Refresh();

            // Already running? 
            if (sc.Status == ServiceControllerStatus.Running) return;

            // Already starting?
            if (sc.Status == ServiceControllerStatus.StartPending)
            {
                sc.WaitForStatus(ServiceControllerStatus.Running, TimeSpan.FromMinutes(2));
                return;
            }

            // Paused?
            if (sc.Status == ServiceControllerStatus.Paused)
            {
                sc.Continue();
                sc.WaitForStatus(ServiceControllerStatus.Running, TimeSpan.FromMinutes(2));
                return;
            }

            // Stopping?
            if (sc.Status == ServiceControllerStatus.StopPending)
            {
                sc.WaitForStatus(ServiceControllerStatus.Stopped, TimeSpan.FromMinutes(2));
            }

            sc.Start();
            sc.WaitForStatus(ServiceControllerStatus.Running, TimeSpan.FromMinutes(2));

            if (sc.Status != ServiceControllerStatus.Running)
                throw new InvalidOperationException("Service failed to reach Running state within the timeout.");
        });

        public Task StopServiceAsync() => Task.Run(() =>
        {
            using var sc = GetService();
            sc.Refresh();

            // Already stopped?
            if (sc.Status == ServiceControllerStatus.Stopped) return;

            // Already stopping?
            if (sc.Status == ServiceControllerStatus.StopPending)
            {
                sc.WaitForStatus(ServiceControllerStatus.Stopped, TimeSpan.FromMinutes(2));
                return;
            }

            // If starting, wait until running, then stop.
            if (sc.Status == ServiceControllerStatus.StartPending)
            {
                sc.WaitForStatus(ServiceControllerStatus.Running, TimeSpan.FromMinutes(2));
            }

            sc.Stop();
            sc.WaitForStatus(ServiceControllerStatus.Stopped, TimeSpan.FromMinutes(2));

            if (sc.Status != ServiceControllerStatus.Stopped)
                throw new InvalidOperationException("Service failed to reach Stopped state within the timeout.");
        });

        public async Task RestartServiceAsync()
        {
            await StopServiceAsync().ConfigureAwait(false);
            await StartServiceAsync().ConfigureAwait(false);
        }

        public ServiceControllerStatus GetStatus()
        {
            using var sc = GetService();
            sc.Refresh();
            return sc.Status;
        }

        public static bool IsProcessElevated()
        {
            try
            {
                var identity = System.Security.Principal.WindowsIdentity.GetCurrent();
                var principal = new System.Security.Principal.WindowsPrincipal(identity);
                return principal.IsInRole(System.Security.Principal.WindowsBuiltInRole.Administrator);
            }
            catch { return false; }
        }

        public Task StartServiceWithScExeFallbackAsync() => Task.Run(() =>
        {
            try
            {
                StartServiceAsync().GetAwaiter().GetResult();
            }
            catch (InvalidOperationException) when (!IsProcessElevated())
            {
                var psi = new ProcessStartInfo("sc.exe", $"start \"{_serviceName}\"")
                {
                    UseShellExecute = true,
                    Verb = "runas",
                    CreateNoWindow = true,
                    WindowStyle = ProcessWindowStyle.Hidden
                };
                var p = Process.Start(psi);
                p?.WaitForExit(60_000);
            }
        });

        public Task StopServiceWithScExeFallbackAsync() => Task.Run(() =>
        {
            try
            {
                StopServiceAsync().GetAwaiter().GetResult();
            }
            catch (InvalidOperationException) when (!IsProcessElevated())
            {
                var psi = new ProcessStartInfo("sc.exe", $"stop \"{_serviceName}\"")
                {
                    UseShellExecute = true,
                    Verb = "runas",
                    CreateNoWindow = true,
                    WindowStyle = ProcessWindowStyle.Hidden
                };
                var p = Process.Start(psi);
                p?.WaitForExit(60_000);
            }
        });

        public async Task RestartServiceWithScExeFallbackAsync()
        {
            await StopServiceWithScExeFallbackAsync().ConfigureAwait(false);
            await StartServiceWithScExeFallbackAsync().ConfigureAwait(false);
        }
    }
}
